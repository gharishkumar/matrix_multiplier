// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.1 (win64) Build 5076996 Wed May 22 18:37:14 MDT 2024
// Date        : Sun Feb  9 20:04:56 2025
// Host        : dvlsi-06 running 64-bit major release  (build 9200)
// Command     : write_verilog -mode funcsim -nolib -force -file {C:/Users/dvlsi/Desktop/FPGA
//               imp/basys3_matrix_multiplication/basys3_matrix_multiplication.sim/sim_1/impl/func/xsim/top_tb_func_impl.v}
// Design      : top
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module PIPO
   (D,
    \d_out_reg[0]_0 ,
    Q,
    clk_IBUF_BUFG);
  output [0:0]D;
  input \d_out_reg[0]_0 ;
  input [0:0]Q;
  input clk_IBUF_BUFG;

  wire [0:0]D;
  wire [0:0]Q;
  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;

  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_0 ),
        .D(Q),
        .Q(D),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_10
   (\d_out_reg[0]_0 ,
    \d_out_reg[0]_1 ,
    clk_IBUF_BUFG,
    \d_out_reg[0]_2 ,
    \d_out_reg[0]_3 );
  output \d_out_reg[0]_0 ;
  input \d_out_reg[0]_1 ;
  input clk_IBUF_BUFG;
  input [0:0]\d_out_reg[0]_2 ;
  input [0:0]\d_out_reg[0]_3 ;

  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire \d_out_reg[0]_1 ;
  wire [0:0]\d_out_reg[0]_2 ;
  wire [0:0]\d_out_reg[0]_3 ;
  wire w5;

  LUT2 #(
    .INIT(4'h8)) 
    \d_out[0]_i_1__3 
       (.I0(\d_out_reg[0]_2 ),
        .I1(\d_out_reg[0]_3 ),
        .O(w5));
  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_1 ),
        .D(w5),
        .Q(\d_out_reg[0]_0 ),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_11
   (D,
    \d_out_reg[0]_0 ,
    \d_out_reg[0]_1 ,
    clk_IBUF_BUFG);
  output [0:0]D;
  input \d_out_reg[0]_0 ;
  input \d_out_reg[0]_1 ;
  input clk_IBUF_BUFG;

  wire [0:0]D;
  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire \d_out_reg[0]_1 ;

  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_0 ),
        .D(\d_out_reg[0]_1 ),
        .Q(D),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_15
   (D,
    \d_out_reg[0]_0 ,
    Q,
    clk_IBUF_BUFG);
  output [0:0]D;
  input \d_out_reg[0]_0 ;
  input [0:0]Q;
  input clk_IBUF_BUFG;

  wire [0:0]D;
  wire [0:0]Q;
  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;

  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_0 ),
        .D(Q),
        .Q(D),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_16
   (\d_out_reg[0]_0 ,
    \d_out_reg[0]_1 ,
    clk_IBUF_BUFG,
    \d_out_reg[0]_2 ,
    \d_out_reg[0]_3 );
  output \d_out_reg[0]_0 ;
  input \d_out_reg[0]_1 ;
  input clk_IBUF_BUFG;
  input [0:0]\d_out_reg[0]_2 ;
  input [0:0]\d_out_reg[0]_3 ;

  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire \d_out_reg[0]_1 ;
  wire [0:0]\d_out_reg[0]_2 ;
  wire [0:0]\d_out_reg[0]_3 ;
  wire w2;

  LUT2 #(
    .INIT(4'h8)) 
    \d_out[0]_i_1__2 
       (.I0(\d_out_reg[0]_2 ),
        .I1(\d_out_reg[0]_3 ),
        .O(w2));
  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_1 ),
        .D(w2),
        .Q(\d_out_reg[0]_0 ),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_17
   (\d_out_reg[0]_0 ,
    \d_out_reg[0]_1 ,
    clk_IBUF_BUFG,
    \d_out_reg[0]_2 ,
    \d_out_reg[0]_3 );
  output \d_out_reg[0]_0 ;
  input \d_out_reg[0]_1 ;
  input clk_IBUF_BUFG;
  input [0:0]\d_out_reg[0]_2 ;
  input [0:0]\d_out_reg[0]_3 ;

  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire \d_out_reg[0]_1 ;
  wire [0:0]\d_out_reg[0]_2 ;
  wire [0:0]\d_out_reg[0]_3 ;
  wire w5;

  LUT2 #(
    .INIT(4'h8)) 
    \d_out[0]_i_1__1 
       (.I0(\d_out_reg[0]_2 ),
        .I1(\d_out_reg[0]_3 ),
        .O(w5));
  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_1 ),
        .D(w5),
        .Q(\d_out_reg[0]_0 ),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_18
   (D,
    \d_out_reg[0]_0 ,
    \d_out_reg[0]_1 ,
    clk_IBUF_BUFG);
  output [0:0]D;
  input \d_out_reg[0]_0 ;
  input \d_out_reg[0]_1 ;
  input clk_IBUF_BUFG;

  wire [0:0]D;
  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire \d_out_reg[0]_1 ;

  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_0 ),
        .D(\d_out_reg[0]_1 ),
        .Q(D),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_22
   (D,
    E,
    Q,
    clk_IBUF_BUFG);
  output [0:0]D;
  input [0:0]E;
  input [0:0]Q;
  input clk_IBUF_BUFG;

  wire [0:0]D;
  wire [0:0]E;
  wire [0:0]Q;
  wire clk_IBUF_BUFG;

  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(Q),
        .Q(D),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_23
   (\d_out_reg[0]_0 ,
    E,
    clk_IBUF_BUFG,
    \d_out_reg[0]_1 ,
    \d_out_reg[0]_2 );
  output \d_out_reg[0]_0 ;
  input [0:0]E;
  input clk_IBUF_BUFG;
  input [0:0]\d_out_reg[0]_1 ;
  input [0:0]\d_out_reg[0]_2 ;

  wire [0:0]E;
  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire [0:0]\d_out_reg[0]_1 ;
  wire [0:0]\d_out_reg[0]_2 ;
  wire w2;

  LUT2 #(
    .INIT(4'h8)) 
    \d_out[0]_i_1__0 
       (.I0(\d_out_reg[0]_1 ),
        .I1(\d_out_reg[0]_2 ),
        .O(w2));
  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(w2),
        .Q(\d_out_reg[0]_0 ),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_24
   (done_s1_3,
    \d_out_reg[0]_0 ,
    done_reg_0,
    reset_n_IBUF,
    do_mul_reg,
    clk_IBUF_BUFG,
    E,
    \d_out_reg[0]_1 ,
    \d_out_reg[0]_2 );
  output done_s1_3;
  output \d_out_reg[0]_0 ;
  output [0:0]done_reg_0;
  input reset_n_IBUF;
  input do_mul_reg;
  input clk_IBUF_BUFG;
  input [0:0]E;
  input [0:0]\d_out_reg[0]_1 ;
  input [0:0]\d_out_reg[0]_2 ;

  wire [0:0]E;
  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire [0:0]\d_out_reg[0]_1 ;
  wire [0:0]\d_out_reg[0]_2 ;
  wire do_mul_reg;
  wire [0:0]done_reg_0;
  wire done_s1_3;
  wire reset_n_IBUF;
  wire w5;

  LUT2 #(
    .INIT(4'h8)) 
    \d_out[0]_i_1 
       (.I0(\d_out_reg[0]_1 ),
        .I1(\d_out_reg[0]_2 ),
        .O(w5));
  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(w5),
        .Q(\d_out_reg[0]_0 ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    done_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(do_mul_reg),
        .Q(done_s1_3),
        .R(reset_n_IBUF));
  LUT2 #(
    .INIT(4'h2)) 
    \result_out[1]_i_1__0 
       (.I0(done_s1_3),
        .I1(reset_n_IBUF),
        .O(done_reg_0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_25
   (done_s2_3,
    D,
    reset_n_IBUF,
    done_s1_3,
    clk_IBUF_BUFG,
    E,
    \d_out_reg[0]_0 );
  output done_s2_3;
  output [0:0]D;
  input reset_n_IBUF;
  input done_s1_3;
  input clk_IBUF_BUFG;
  input [0:0]E;
  input \d_out_reg[0]_0 ;

  wire [0:0]D;
  wire [0:0]E;
  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire done_s1_3;
  wire done_s2_3;
  wire reset_n_IBUF;

  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\d_out_reg[0]_0 ),
        .Q(D),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    done_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(done_s1_3),
        .Q(done_s2_3),
        .R(reset_n_IBUF));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_3
   (\d_out_reg[0]_0 ,
    \d_out_reg[0]_1 ,
    clk_IBUF_BUFG,
    \d_out_reg[0]_2 ,
    \d_out_reg[0]_3 );
  output \d_out_reg[0]_0 ;
  input \d_out_reg[0]_1 ;
  input clk_IBUF_BUFG;
  input [0:0]\d_out_reg[0]_2 ;
  input [0:0]\d_out_reg[0]_3 ;

  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire \d_out_reg[0]_1 ;
  wire [0:0]\d_out_reg[0]_2 ;
  wire [0:0]\d_out_reg[0]_3 ;
  wire w2;

  LUT2 #(
    .INIT(4'h8)) 
    \d_out[0]_i_1__6 
       (.I0(\d_out_reg[0]_2 ),
        .I1(\d_out_reg[0]_3 ),
        .O(w2));
  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_1 ),
        .D(w2),
        .Q(\d_out_reg[0]_0 ),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_4
   (\d_out_reg[0]_0 ,
    \d_out_reg[0]_1 ,
    clk_IBUF_BUFG,
    \d_out_reg[0]_2 ,
    \d_out_reg[0]_3 );
  output \d_out_reg[0]_0 ;
  input \d_out_reg[0]_1 ;
  input clk_IBUF_BUFG;
  input [0:0]\d_out_reg[0]_2 ;
  input [0:0]\d_out_reg[0]_3 ;

  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire \d_out_reg[0]_1 ;
  wire [0:0]\d_out_reg[0]_2 ;
  wire [0:0]\d_out_reg[0]_3 ;
  wire w5;

  LUT2 #(
    .INIT(4'h8)) 
    \d_out[0]_i_1__5 
       (.I0(\d_out_reg[0]_2 ),
        .I1(\d_out_reg[0]_3 ),
        .O(w5));
  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_1 ),
        .D(w5),
        .Q(\d_out_reg[0]_0 ),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_5
   (D,
    \d_out_reg[0]_0 ,
    \d_out_reg[0]_1 ,
    clk_IBUF_BUFG);
  output [0:0]D;
  input \d_out_reg[0]_0 ;
  input \d_out_reg[0]_1 ;
  input clk_IBUF_BUFG;

  wire [0:0]D;
  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire \d_out_reg[0]_1 ;

  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_0 ),
        .D(\d_out_reg[0]_1 ),
        .Q(D),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_8
   (D,
    \d_out_reg[0]_0 ,
    Q,
    clk_IBUF_BUFG);
  output [0:0]D;
  input \d_out_reg[0]_0 ;
  input [0:0]Q;
  input clk_IBUF_BUFG;

  wire [0:0]D;
  wire [0:0]Q;
  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;

  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_0 ),
        .D(Q),
        .Q(D),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "PIPO" *) 
module PIPO_9
   (\d_out_reg[0]_0 ,
    \d_out_reg[0]_1 ,
    clk_IBUF_BUFG,
    \d_out_reg[0]_2 ,
    \d_out_reg[0]_3 );
  output \d_out_reg[0]_0 ;
  input \d_out_reg[0]_1 ;
  input clk_IBUF_BUFG;
  input [0:0]\d_out_reg[0]_2 ;
  input [0:0]\d_out_reg[0]_3 ;

  wire clk_IBUF_BUFG;
  wire \d_out_reg[0]_0 ;
  wire \d_out_reg[0]_1 ;
  wire [0:0]\d_out_reg[0]_2 ;
  wire [0:0]\d_out_reg[0]_3 ;
  wire w2;

  LUT2 #(
    .INIT(4'h8)) 
    \d_out[0]_i_1__4 
       (.I0(\d_out_reg[0]_2 ),
        .I1(\d_out_reg[0]_3 ),
        .O(w2));
  FDRE #(
    .INIT(1'b0)) 
    \d_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\d_out_reg[0]_1 ),
        .D(w2),
        .Q(\d_out_reg[0]_0 ),
        .R(1'b0));
endmodule

module adder
   (Q,
    \result_out_reg[0]_0 ,
    clk_IBUF_BUFG,
    \result_out_reg[1]_0 ,
    \result_out_reg[1]_1 );
  output [1:0]Q;
  input \result_out_reg[0]_0 ;
  input clk_IBUF_BUFG;
  input [1:0]\result_out_reg[1]_0 ;
  input [1:0]\result_out_reg[1]_1 ;

  wire [1:0]Q;
  wire clk_IBUF_BUFG;
  wire \result_out[0]_i_1_n_0 ;
  wire \result_out[1]_i_1_n_0 ;
  wire \result_out_reg[0]_0 ;
  wire [1:0]\result_out_reg[1]_0 ;
  wire [1:0]\result_out_reg[1]_1 ;

  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT4 #(
    .INIT(16'h7888)) 
    \result_out[0]_i_1 
       (.I0(\result_out_reg[1]_0 [1]),
        .I1(\result_out_reg[1]_1 [0]),
        .I2(\result_out_reg[1]_0 [0]),
        .I3(\result_out_reg[1]_1 [1]),
        .O(\result_out[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \result_out[1]_i_1 
       (.I0(\result_out_reg[1]_0 [0]),
        .I1(\result_out_reg[1]_1 [1]),
        .I2(\result_out_reg[1]_0 [1]),
        .I3(\result_out_reg[1]_1 [0]),
        .O(\result_out[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_0 ),
        .D(\result_out[0]_i_1_n_0 ),
        .Q(Q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_0 ),
        .D(\result_out[1]_i_1_n_0 ),
        .Q(Q[1]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "adder" *) 
module adder_12
   (Q,
    \result_out_reg[0]_0 ,
    clk_IBUF_BUFG,
    \result_out_reg[1]_0 ,
    \result_out_reg[1]_1 );
  output [1:0]Q;
  input \result_out_reg[0]_0 ;
  input clk_IBUF_BUFG;
  input [1:0]\result_out_reg[1]_0 ;
  input [1:0]\result_out_reg[1]_1 ;

  wire [1:0]Q;
  wire clk_IBUF_BUFG;
  wire \result_out[0]_i_1_n_0 ;
  wire \result_out[1]_i_1_n_0 ;
  wire \result_out_reg[0]_0 ;
  wire [1:0]\result_out_reg[1]_0 ;
  wire [1:0]\result_out_reg[1]_1 ;

  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'h7888)) 
    \result_out[0]_i_1 
       (.I0(\result_out_reg[1]_0 [1]),
        .I1(\result_out_reg[1]_1 [0]),
        .I2(\result_out_reg[1]_0 [0]),
        .I3(\result_out_reg[1]_1 [1]),
        .O(\result_out[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \result_out[1]_i_1 
       (.I0(\result_out_reg[1]_0 [0]),
        .I1(\result_out_reg[1]_1 [1]),
        .I2(\result_out_reg[1]_0 [1]),
        .I3(\result_out_reg[1]_1 [0]),
        .O(\result_out[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_0 ),
        .D(\result_out[0]_i_1_n_0 ),
        .Q(Q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_0 ),
        .D(\result_out[1]_i_1_n_0 ),
        .Q(Q[1]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "adder" *) 
module adder_13
   (\result_out_reg[1]_0 ,
    \result_out_reg[0]_0 ,
    Q,
    \result_out_reg[0]_1 ,
    clk_IBUF_BUFG);
  output [1:0]\result_out_reg[1]_0 ;
  input \result_out_reg[0]_0 ;
  input [0:0]Q;
  input \result_out_reg[0]_1 ;
  input clk_IBUF_BUFG;

  wire [0:0]Q;
  wire clk_IBUF_BUFG;
  wire \result_out[0]_i_1_n_0 ;
  wire \result_out[1]_i_1_n_0 ;
  wire \result_out_reg[0]_0 ;
  wire \result_out_reg[0]_1 ;
  wire [1:0]\result_out_reg[1]_0 ;

  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \result_out[0]_i_1 
       (.I0(\result_out_reg[0]_0 ),
        .I1(Q),
        .O(\result_out[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \result_out[1]_i_1 
       (.I0(Q),
        .I1(\result_out_reg[0]_0 ),
        .O(\result_out[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_1 ),
        .D(\result_out[0]_i_1_n_0 ),
        .Q(\result_out_reg[1]_0 [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_1 ),
        .D(\result_out[1]_i_1_n_0 ),
        .Q(\result_out_reg[1]_0 [1]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "adder" *) 
module adder_19
   (Q,
    \result_out_reg[0]_0 ,
    clk_IBUF_BUFG,
    \result_out_reg[1]_0 ,
    \result_out_reg[1]_1 );
  output [1:0]Q;
  input \result_out_reg[0]_0 ;
  input clk_IBUF_BUFG;
  input [1:0]\result_out_reg[1]_0 ;
  input [1:0]\result_out_reg[1]_1 ;

  wire [1:0]Q;
  wire clk_IBUF_BUFG;
  wire \result_out[0]_i_1_n_0 ;
  wire \result_out[1]_i_1_n_0 ;
  wire \result_out_reg[0]_0 ;
  wire [1:0]\result_out_reg[1]_0 ;
  wire [1:0]\result_out_reg[1]_1 ;

  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h7888)) 
    \result_out[0]_i_1 
       (.I0(\result_out_reg[1]_0 [1]),
        .I1(\result_out_reg[1]_1 [0]),
        .I2(\result_out_reg[1]_0 [0]),
        .I3(\result_out_reg[1]_1 [1]),
        .O(\result_out[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \result_out[1]_i_1 
       (.I0(\result_out_reg[1]_0 [0]),
        .I1(\result_out_reg[1]_1 [1]),
        .I2(\result_out_reg[1]_0 [1]),
        .I3(\result_out_reg[1]_1 [0]),
        .O(\result_out[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_0 ),
        .D(\result_out[0]_i_1_n_0 ),
        .Q(Q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_0 ),
        .D(\result_out[1]_i_1_n_0 ),
        .Q(Q[1]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "adder" *) 
module adder_20
   (\result_out_reg[1]_0 ,
    \result_out_reg[0]_0 ,
    Q,
    \result_out_reg[0]_1 ,
    clk_IBUF_BUFG);
  output [1:0]\result_out_reg[1]_0 ;
  input \result_out_reg[0]_0 ;
  input [0:0]Q;
  input \result_out_reg[0]_1 ;
  input clk_IBUF_BUFG;

  wire [0:0]Q;
  wire clk_IBUF_BUFG;
  wire \result_out[0]_i_1_n_0 ;
  wire \result_out[1]_i_1_n_0 ;
  wire \result_out_reg[0]_0 ;
  wire \result_out_reg[0]_1 ;
  wire [1:0]\result_out_reg[1]_0 ;

  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \result_out[0]_i_1 
       (.I0(\result_out_reg[0]_0 ),
        .I1(Q),
        .O(\result_out[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \result_out[1]_i_1 
       (.I0(Q),
        .I1(\result_out_reg[0]_0 ),
        .O(\result_out[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_1 ),
        .D(\result_out[0]_i_1_n_0 ),
        .Q(\result_out_reg[1]_0 [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_1 ),
        .D(\result_out[1]_i_1_n_0 ),
        .Q(\result_out_reg[1]_0 [1]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "adder" *) 
module adder_26
   (E,
    Q,
    do_mul_reg,
    reset_n_IBUF,
    clk_IBUF_BUFG,
    \result_out_reg[1]_0 ,
    \result_out_reg[1]_1 );
  output [0:0]E;
  output [1:0]Q;
  input do_mul_reg;
  input reset_n_IBUF;
  input clk_IBUF_BUFG;
  input [1:0]\result_out_reg[1]_0 ;
  input [1:0]\result_out_reg[1]_1 ;

  wire [0:0]E;
  wire [1:0]Q;
  wire clk_IBUF_BUFG;
  wire do_mul_reg;
  wire [1:0]p_0_in;
  wire reset_n_IBUF;
  wire [1:0]\result_out_reg[1]_0 ;
  wire [1:0]\result_out_reg[1]_1 ;

  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h7888)) 
    \result_out[0]_i_1 
       (.I0(\result_out_reg[1]_0 [1]),
        .I1(\result_out_reg[1]_1 [0]),
        .I2(\result_out_reg[1]_0 [0]),
        .I3(\result_out_reg[1]_1 [1]),
        .O(p_0_in[0]));
  LUT2 #(
    .INIT(4'h2)) 
    \result_out[1]_i_1 
       (.I0(do_mul_reg),
        .I1(reset_n_IBUF),
        .O(E));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \result_out[1]_i_2 
       (.I0(\result_out_reg[1]_0 [0]),
        .I1(\result_out_reg[1]_1 [1]),
        .I2(\result_out_reg[1]_0 [1]),
        .I3(\result_out_reg[1]_1 [0]),
        .O(p_0_in[1]));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(p_0_in[0]),
        .Q(Q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(p_0_in[1]),
        .Q(Q[1]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "adder" *) 
module adder_27
   (\result_out_reg[1]_0 ,
    \result_out_reg[0]_0 ,
    Q,
    E,
    clk_IBUF_BUFG);
  output [1:0]\result_out_reg[1]_0 ;
  input \result_out_reg[0]_0 ;
  input [0:0]Q;
  input [0:0]E;
  input clk_IBUF_BUFG;

  wire [0:0]E;
  wire [0:0]Q;
  wire clk_IBUF_BUFG;
  wire \result_out[0]_i_1_n_0 ;
  wire \result_out[1]_i_2_n_0 ;
  wire \result_out_reg[0]_0 ;
  wire [1:0]\result_out_reg[1]_0 ;

  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \result_out[0]_i_1 
       (.I0(\result_out_reg[0]_0 ),
        .I1(Q),
        .O(\result_out[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \result_out[1]_i_2 
       (.I0(Q),
        .I1(\result_out_reg[0]_0 ),
        .O(\result_out[1]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\result_out[0]_i_1_n_0 ),
        .Q(\result_out_reg[1]_0 [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\result_out[1]_i_2_n_0 ),
        .Q(\result_out_reg[1]_0 [1]),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "adder" *) 
module adder_6
   (\result_out_reg[1]_0 ,
    \result_out_reg[0]_0 ,
    Q,
    \result_out_reg[0]_1 ,
    clk_IBUF_BUFG);
  output [1:0]\result_out_reg[1]_0 ;
  input \result_out_reg[0]_0 ;
  input [0:0]Q;
  input \result_out_reg[0]_1 ;
  input clk_IBUF_BUFG;

  wire [0:0]Q;
  wire clk_IBUF_BUFG;
  wire \result_out[0]_i_1_n_0 ;
  wire \result_out[1]_i_1_n_0 ;
  wire \result_out_reg[0]_0 ;
  wire \result_out_reg[0]_1 ;
  wire [1:0]\result_out_reg[1]_0 ;

  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \result_out[0]_i_1 
       (.I0(\result_out_reg[0]_0 ),
        .I1(Q),
        .O(\result_out[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \result_out[1]_i_1 
       (.I0(Q),
        .I1(\result_out_reg[0]_0 ),
        .O(\result_out[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_1 ),
        .D(\result_out[0]_i_1_n_0 ),
        .Q(\result_out_reg[1]_0 [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_out_reg[0]_1 ),
        .D(\result_out[1]_i_1_n_0 ),
        .Q(\result_out_reg[1]_0 [1]),
        .R(1'b0));
endmodule

module clkgen
   (CLK,
    tmp_clk_reg_0,
    clk_IBUF_BUFG);
  output CLK;
  output tmp_clk_reg_0;
  input clk_IBUF_BUFG;

  wire CLK;
  wire clear;
  wire clk_IBUF_BUFG;
  wire \count[0]_i_1_n_0 ;
  wire \count[0]_i_3_n_0 ;
  wire \count[0]_i_4_n_0 ;
  wire \count[0]_i_5_n_0 ;
  wire \count[0]_i_6_n_0 ;
  wire [26:8]count_reg;
  wire \count_reg[0]_i_2_n_0 ;
  wire \count_reg[0]_i_2_n_4 ;
  wire \count_reg[0]_i_2_n_5 ;
  wire \count_reg[0]_i_2_n_6 ;
  wire \count_reg[0]_i_2_n_7 ;
  wire \count_reg[12]_i_1_n_0 ;
  wire \count_reg[12]_i_1_n_4 ;
  wire \count_reg[12]_i_1_n_5 ;
  wire \count_reg[12]_i_1_n_6 ;
  wire \count_reg[12]_i_1_n_7 ;
  wire \count_reg[16]_i_1_n_0 ;
  wire \count_reg[16]_i_1_n_4 ;
  wire \count_reg[16]_i_1_n_5 ;
  wire \count_reg[16]_i_1_n_6 ;
  wire \count_reg[16]_i_1_n_7 ;
  wire \count_reg[20]_i_1_n_0 ;
  wire \count_reg[20]_i_1_n_4 ;
  wire \count_reg[20]_i_1_n_5 ;
  wire \count_reg[20]_i_1_n_6 ;
  wire \count_reg[20]_i_1_n_7 ;
  wire \count_reg[24]_i_1_n_5 ;
  wire \count_reg[24]_i_1_n_6 ;
  wire \count_reg[24]_i_1_n_7 ;
  wire \count_reg[4]_i_1_n_0 ;
  wire \count_reg[4]_i_1_n_4 ;
  wire \count_reg[4]_i_1_n_5 ;
  wire \count_reg[4]_i_1_n_6 ;
  wire \count_reg[4]_i_1_n_7 ;
  wire \count_reg[8]_i_1_n_0 ;
  wire \count_reg[8]_i_1_n_4 ;
  wire \count_reg[8]_i_1_n_5 ;
  wire \count_reg[8]_i_1_n_6 ;
  wire \count_reg[8]_i_1_n_7 ;
  wire \count_reg_n_0_[0] ;
  wire \count_reg_n_0_[1] ;
  wire \count_reg_n_0_[2] ;
  wire \count_reg_n_0_[3] ;
  wire \count_reg_n_0_[4] ;
  wire \count_reg_n_0_[5] ;
  wire \count_reg_n_0_[6] ;
  wire \count_reg_n_0_[7] ;
  wire rclk_i_1_n_0;
  wire \refresh[0]_i_3_n_0 ;
  wire \refresh[0]_i_4_n_0 ;
  wire \refresh[0]_i_5_n_0 ;
  wire [16:5]refresh_reg;
  wire \refresh_reg[0]_i_2_n_0 ;
  wire \refresh_reg[0]_i_2_n_4 ;
  wire \refresh_reg[0]_i_2_n_5 ;
  wire \refresh_reg[0]_i_2_n_6 ;
  wire \refresh_reg[0]_i_2_n_7 ;
  wire \refresh_reg[12]_i_1_n_0 ;
  wire \refresh_reg[12]_i_1_n_4 ;
  wire \refresh_reg[12]_i_1_n_5 ;
  wire \refresh_reg[12]_i_1_n_6 ;
  wire \refresh_reg[12]_i_1_n_7 ;
  wire \refresh_reg[16]_i_1_n_7 ;
  wire \refresh_reg[4]_i_1_n_0 ;
  wire \refresh_reg[4]_i_1_n_4 ;
  wire \refresh_reg[4]_i_1_n_5 ;
  wire \refresh_reg[4]_i_1_n_6 ;
  wire \refresh_reg[4]_i_1_n_7 ;
  wire \refresh_reg[8]_i_1_n_0 ;
  wire \refresh_reg[8]_i_1_n_4 ;
  wire \refresh_reg[8]_i_1_n_5 ;
  wire \refresh_reg[8]_i_1_n_6 ;
  wire \refresh_reg[8]_i_1_n_7 ;
  wire \refresh_reg_n_0_[0] ;
  wire \refresh_reg_n_0_[1] ;
  wire \refresh_reg_n_0_[2] ;
  wire \refresh_reg_n_0_[3] ;
  wire \refresh_reg_n_0_[4] ;
  wire tmp_clk_i_1_n_0;
  wire tmp_clk_i_2_n_0;
  wire tmp_clk_i_3_n_0;
  wire tmp_clk_reg_0;
  wire [2:0]\NLW_count_reg[0]_i_2_CO_UNCONNECTED ;
  wire [2:0]\NLW_count_reg[12]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_count_reg[16]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_count_reg[20]_i_1_CO_UNCONNECTED ;
  wire [3:0]\NLW_count_reg[24]_i_1_CO_UNCONNECTED ;
  wire [3:3]\NLW_count_reg[24]_i_1_O_UNCONNECTED ;
  wire [2:0]\NLW_count_reg[4]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_count_reg[8]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_refresh_reg[0]_i_2_CO_UNCONNECTED ;
  wire [2:0]\NLW_refresh_reg[12]_i_1_CO_UNCONNECTED ;
  wire [3:0]\NLW_refresh_reg[16]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_refresh_reg[16]_i_1_O_UNCONNECTED ;
  wire [2:0]\NLW_refresh_reg[4]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_refresh_reg[8]_i_1_CO_UNCONNECTED ;

  LUT6 #(
    .INIT(64'h8A8A8A8A88888A88)) 
    \count[0]_i_1 
       (.I0(count_reg[26]),
        .I1(count_reg[25]),
        .I2(\count[0]_i_3_n_0 ),
        .I3(count_reg[18]),
        .I4(\count[0]_i_4_n_0 ),
        .I5(count_reg[19]),
        .O(\count[0]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \count[0]_i_3 
       (.I0(count_reg[20]),
        .I1(count_reg[24]),
        .I2(count_reg[23]),
        .I3(count_reg[21]),
        .I4(count_reg[22]),
        .O(\count[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h000000007FFFFFFF)) 
    \count[0]_i_4 
       (.I0(\count[0]_i_6_n_0 ),
        .I1(count_reg[15]),
        .I2(count_reg[16]),
        .I3(count_reg[13]),
        .I4(count_reg[14]),
        .I5(count_reg[17]),
        .O(\count[0]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \count[0]_i_5 
       (.I0(\count_reg_n_0_[0] ),
        .O(\count[0]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \count[0]_i_6 
       (.I0(count_reg[8]),
        .I1(count_reg[10]),
        .I2(count_reg[12]),
        .I3(count_reg[11]),
        .I4(count_reg[9]),
        .O(\count[0]_i_6_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[0]_i_2_n_7 ),
        .Q(\count_reg_n_0_[0] ),
        .R(\count[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_reg[0]_i_2 
       (.CI(1'b0),
        .CO({\count_reg[0]_i_2_n_0 ,\NLW_count_reg[0]_i_2_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\count_reg[0]_i_2_n_4 ,\count_reg[0]_i_2_n_5 ,\count_reg[0]_i_2_n_6 ,\count_reg[0]_i_2_n_7 }),
        .S({\count_reg_n_0_[3] ,\count_reg_n_0_[2] ,\count_reg_n_0_[1] ,\count[0]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[8]_i_1_n_5 ),
        .Q(count_reg[10]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[8]_i_1_n_4 ),
        .Q(count_reg[11]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[12] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[12]_i_1_n_7 ),
        .Q(count_reg[12]),
        .R(\count[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_reg[12]_i_1 
       (.CI(\count_reg[8]_i_1_n_0 ),
        .CO({\count_reg[12]_i_1_n_0 ,\NLW_count_reg[12]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_reg[12]_i_1_n_4 ,\count_reg[12]_i_1_n_5 ,\count_reg[12]_i_1_n_6 ,\count_reg[12]_i_1_n_7 }),
        .S(count_reg[15:12]));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[13] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[12]_i_1_n_6 ),
        .Q(count_reg[13]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[14] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[12]_i_1_n_5 ),
        .Q(count_reg[14]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[15] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[12]_i_1_n_4 ),
        .Q(count_reg[15]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[16] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[16]_i_1_n_7 ),
        .Q(count_reg[16]),
        .R(\count[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_reg[16]_i_1 
       (.CI(\count_reg[12]_i_1_n_0 ),
        .CO({\count_reg[16]_i_1_n_0 ,\NLW_count_reg[16]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_reg[16]_i_1_n_4 ,\count_reg[16]_i_1_n_5 ,\count_reg[16]_i_1_n_6 ,\count_reg[16]_i_1_n_7 }),
        .S(count_reg[19:16]));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[17] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[16]_i_1_n_6 ),
        .Q(count_reg[17]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[18] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[16]_i_1_n_5 ),
        .Q(count_reg[18]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[19] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[16]_i_1_n_4 ),
        .Q(count_reg[19]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[0]_i_2_n_6 ),
        .Q(\count_reg_n_0_[1] ),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[20] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[20]_i_1_n_7 ),
        .Q(count_reg[20]),
        .R(\count[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_reg[20]_i_1 
       (.CI(\count_reg[16]_i_1_n_0 ),
        .CO({\count_reg[20]_i_1_n_0 ,\NLW_count_reg[20]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_reg[20]_i_1_n_4 ,\count_reg[20]_i_1_n_5 ,\count_reg[20]_i_1_n_6 ,\count_reg[20]_i_1_n_7 }),
        .S(count_reg[23:20]));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[21] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[20]_i_1_n_6 ),
        .Q(count_reg[21]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[22] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[20]_i_1_n_5 ),
        .Q(count_reg[22]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[23] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[20]_i_1_n_4 ),
        .Q(count_reg[23]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[24] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[24]_i_1_n_7 ),
        .Q(count_reg[24]),
        .R(\count[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_reg[24]_i_1 
       (.CI(\count_reg[20]_i_1_n_0 ),
        .CO(\NLW_count_reg[24]_i_1_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_count_reg[24]_i_1_O_UNCONNECTED [3],\count_reg[24]_i_1_n_5 ,\count_reg[24]_i_1_n_6 ,\count_reg[24]_i_1_n_7 }),
        .S({1'b0,count_reg[26:24]}));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[25] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[24]_i_1_n_6 ),
        .Q(count_reg[25]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[26] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[24]_i_1_n_5 ),
        .Q(count_reg[26]),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[0]_i_2_n_5 ),
        .Q(\count_reg_n_0_[2] ),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[0]_i_2_n_4 ),
        .Q(\count_reg_n_0_[3] ),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[4]_i_1_n_7 ),
        .Q(\count_reg_n_0_[4] ),
        .R(\count[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_reg[4]_i_1 
       (.CI(\count_reg[0]_i_2_n_0 ),
        .CO({\count_reg[4]_i_1_n_0 ,\NLW_count_reg[4]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_reg[4]_i_1_n_4 ,\count_reg[4]_i_1_n_5 ,\count_reg[4]_i_1_n_6 ,\count_reg[4]_i_1_n_7 }),
        .S({\count_reg_n_0_[7] ,\count_reg_n_0_[6] ,\count_reg_n_0_[5] ,\count_reg_n_0_[4] }));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[4]_i_1_n_6 ),
        .Q(\count_reg_n_0_[5] ),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[4]_i_1_n_5 ),
        .Q(\count_reg_n_0_[6] ),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[4]_i_1_n_4 ),
        .Q(\count_reg_n_0_[7] ),
        .R(\count[0]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[8]_i_1_n_7 ),
        .Q(count_reg[8]),
        .R(\count[0]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \count_reg[8]_i_1 
       (.CI(\count_reg[4]_i_1_n_0 ),
        .CO({\count_reg[8]_i_1_n_0 ,\NLW_count_reg[8]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\count_reg[8]_i_1_n_4 ,\count_reg[8]_i_1_n_5 ,\count_reg[8]_i_1_n_6 ,\count_reg[8]_i_1_n_7 }),
        .S(count_reg[11:8]));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count_reg[8]_i_1_n_6 ),
        .Q(count_reg[9]),
        .R(\count[0]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h1FFFE000)) 
    rclk_i_1
       (.I0(\refresh[0]_i_3_n_0 ),
        .I1(\refresh[0]_i_4_n_0 ),
        .I2(refresh_reg[15]),
        .I3(refresh_reg[16]),
        .I4(CLK),
        .O(rclk_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    rclk_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(rclk_i_1_n_0),
        .Q(CLK),
        .R(1'b0));
  LUT4 #(
    .INIT(16'hE000)) 
    \refresh[0]_i_1 
       (.I0(\refresh[0]_i_3_n_0 ),
        .I1(\refresh[0]_i_4_n_0 ),
        .I2(refresh_reg[15]),
        .I3(refresh_reg[16]),
        .O(clear));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \refresh[0]_i_3 
       (.I0(refresh_reg[11]),
        .I1(refresh_reg[14]),
        .I2(refresh_reg[12]),
        .I3(refresh_reg[13]),
        .O(\refresh[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFA8000000000000)) 
    \refresh[0]_i_4 
       (.I0(refresh_reg[7]),
        .I1(refresh_reg[6]),
        .I2(refresh_reg[5]),
        .I3(refresh_reg[8]),
        .I4(refresh_reg[9]),
        .I5(refresh_reg[10]),
        .O(\refresh[0]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \refresh[0]_i_5 
       (.I0(\refresh_reg_n_0_[0] ),
        .O(\refresh[0]_i_5_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[0]_i_2_n_7 ),
        .Q(\refresh_reg_n_0_[0] ),
        .R(clear));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \refresh_reg[0]_i_2 
       (.CI(1'b0),
        .CO({\refresh_reg[0]_i_2_n_0 ,\NLW_refresh_reg[0]_i_2_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\refresh_reg[0]_i_2_n_4 ,\refresh_reg[0]_i_2_n_5 ,\refresh_reg[0]_i_2_n_6 ,\refresh_reg[0]_i_2_n_7 }),
        .S({\refresh_reg_n_0_[3] ,\refresh_reg_n_0_[2] ,\refresh_reg_n_0_[1] ,\refresh[0]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[8]_i_1_n_5 ),
        .Q(refresh_reg[10]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[8]_i_1_n_4 ),
        .Q(refresh_reg[11]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[12] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[12]_i_1_n_7 ),
        .Q(refresh_reg[12]),
        .R(clear));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \refresh_reg[12]_i_1 
       (.CI(\refresh_reg[8]_i_1_n_0 ),
        .CO({\refresh_reg[12]_i_1_n_0 ,\NLW_refresh_reg[12]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\refresh_reg[12]_i_1_n_4 ,\refresh_reg[12]_i_1_n_5 ,\refresh_reg[12]_i_1_n_6 ,\refresh_reg[12]_i_1_n_7 }),
        .S(refresh_reg[15:12]));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[13] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[12]_i_1_n_6 ),
        .Q(refresh_reg[13]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[14] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[12]_i_1_n_5 ),
        .Q(refresh_reg[14]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[15] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[12]_i_1_n_4 ),
        .Q(refresh_reg[15]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[16] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[16]_i_1_n_7 ),
        .Q(refresh_reg[16]),
        .R(clear));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \refresh_reg[16]_i_1 
       (.CI(\refresh_reg[12]_i_1_n_0 ),
        .CO(\NLW_refresh_reg[16]_i_1_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_refresh_reg[16]_i_1_O_UNCONNECTED [3:1],\refresh_reg[16]_i_1_n_7 }),
        .S({1'b0,1'b0,1'b0,refresh_reg[16]}));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[0]_i_2_n_6 ),
        .Q(\refresh_reg_n_0_[1] ),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[0]_i_2_n_5 ),
        .Q(\refresh_reg_n_0_[2] ),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[0]_i_2_n_4 ),
        .Q(\refresh_reg_n_0_[3] ),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[4]_i_1_n_7 ),
        .Q(\refresh_reg_n_0_[4] ),
        .R(clear));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \refresh_reg[4]_i_1 
       (.CI(\refresh_reg[0]_i_2_n_0 ),
        .CO({\refresh_reg[4]_i_1_n_0 ,\NLW_refresh_reg[4]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\refresh_reg[4]_i_1_n_4 ,\refresh_reg[4]_i_1_n_5 ,\refresh_reg[4]_i_1_n_6 ,\refresh_reg[4]_i_1_n_7 }),
        .S({refresh_reg[7:5],\refresh_reg_n_0_[4] }));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[4]_i_1_n_6 ),
        .Q(refresh_reg[5]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[4]_i_1_n_5 ),
        .Q(refresh_reg[6]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[4]_i_1_n_4 ),
        .Q(refresh_reg[7]),
        .R(clear));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[8]_i_1_n_7 ),
        .Q(refresh_reg[8]),
        .R(clear));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \refresh_reg[8]_i_1 
       (.CI(\refresh_reg[4]_i_1_n_0 ),
        .CO({\refresh_reg[8]_i_1_n_0 ,\NLW_refresh_reg[8]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\refresh_reg[8]_i_1_n_4 ,\refresh_reg[8]_i_1_n_5 ,\refresh_reg[8]_i_1_n_6 ,\refresh_reg[8]_i_1_n_7 }),
        .S(refresh_reg[11:8]));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\refresh_reg[8]_i_1_n_6 ),
        .Q(refresh_reg[9]),
        .R(clear));
  LUT4 #(
    .INIT(16'h2FD0)) 
    tmp_clk_i_1
       (.I0(tmp_clk_i_2_n_0),
        .I1(count_reg[25]),
        .I2(count_reg[26]),
        .I3(tmp_clk_reg_0),
        .O(tmp_clk_i_1_n_0));
  LUT6 #(
    .INIT(64'hAAAAAAAABFBBBFBF)) 
    tmp_clk_i_2
       (.I0(\count[0]_i_3_n_0 ),
        .I1(count_reg[18]),
        .I2(count_reg[17]),
        .I3(tmp_clk_i_3_n_0),
        .I4(\count[0]_i_6_n_0 ),
        .I5(count_reg[19]),
        .O(tmp_clk_i_2_n_0));
  LUT4 #(
    .INIT(16'h7FFF)) 
    tmp_clk_i_3
       (.I0(count_reg[15]),
        .I1(count_reg[16]),
        .I2(count_reg[13]),
        .I3(count_reg[14]),
        .O(tmp_clk_i_3_n_0));
  FDRE #(
    .INIT(1'b0)) 
    tmp_clk_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(tmp_clk_i_1_n_0),
        .Q(tmp_clk_reg_0),
        .R(1'b0));
endmodule

module counter
   (led_OBUF,
    segment_OBUF,
    reset_n_IBUF,
    CLK,
    button_n_IBUF,
    Q,
    \segment[4] );
  output [4:0]led_OBUF;
  output [2:0]segment_OBUF;
  input reset_n_IBUF;
  input CLK;
  input button_n_IBUF;
  input [19:0]Q;
  input [1:0]\segment[4] ;

  wire CLK;
  wire [19:0]Q;
  wire button_n_IBUF;
  wire button_n_ff;
  wire [1:0]hex;
  wire [4:0]led_OBUF;
  wire \led_OBUF[0]_inst_i_2_n_0 ;
  wire \led_OBUF[1]_inst_i_2_n_0 ;
  wire \led_OBUF[2]_inst_i_2_n_0 ;
  wire \led_OBUF[3]_inst_i_2_n_0 ;
  wire \led_OBUF[3]_inst_i_3_n_0 ;
  wire \led_OBUF[4]_inst_i_2_n_0 ;
  wire \led_OBUF[4]_inst_i_3_n_0 ;
  wire \led_OBUF[4]_inst_i_4_n_0 ;
  wire \led_OBUF[4]_inst_i_5_n_0 ;
  wire [3:0]reg_d0;
  wire reg_d00;
  wire \reg_d0[0]_i_1_n_0 ;
  wire \reg_d0[1]_i_1_n_0 ;
  wire \reg_d0[2]_i_1_n_0 ;
  wire \reg_d0[3]_i_2_n_0 ;
  wire [3:0]reg_d1;
  wire \reg_d1[0]_i_1_n_0 ;
  wire \reg_d1[1]_i_1_n_0 ;
  wire \reg_d1[2]_i_1_n_0 ;
  wire \reg_d1[3]_i_1_n_0 ;
  wire \reg_d1[3]_i_2_n_0 ;
  wire reset;
  wire reset_i_1_n_0;
  wire reset_n_IBUF;
  wire reset_n_ff;
  wire [1:0]\segment[4] ;
  wire [2:0]segment_OBUF;
  wire \segment_OBUF[6]_inst_i_3_n_0 ;
  wire start_stop;
  wire start_stop_inv_i_1_n_0;

  FDRE #(
    .INIT(1'b0)) 
    button_n_ff_reg
       (.C(CLK),
        .CE(1'b1),
        .D(button_n_IBUF),
        .Q(button_n_ff),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hAAAAA888A888A888)) 
    \led_OBUF[0]_inst_i_1 
       (.I0(\led_OBUF[4]_inst_i_2_n_0 ),
        .I1(\led_OBUF[0]_inst_i_2_n_0 ),
        .I2(Q[0]),
        .I3(\led_OBUF[4]_inst_i_4_n_0 ),
        .I4(Q[10]),
        .I5(\led_OBUF[3]_inst_i_3_n_0 ),
        .O(led_OBUF[0]));
  LUT6 #(
    .INIT(64'h00000CA000000000)) 
    \led_OBUF[0]_inst_i_2 
       (.I0(Q[5]),
        .I1(Q[15]),
        .I2(reg_d1[0]),
        .I3(reg_d1[1]),
        .I4(reg_d0[0]),
        .I5(reg_d0[1]),
        .O(\led_OBUF[0]_inst_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAA888A888A888)) 
    \led_OBUF[1]_inst_i_1 
       (.I0(\led_OBUF[4]_inst_i_2_n_0 ),
        .I1(\led_OBUF[1]_inst_i_2_n_0 ),
        .I2(Q[1]),
        .I3(\led_OBUF[4]_inst_i_4_n_0 ),
        .I4(Q[11]),
        .I5(\led_OBUF[3]_inst_i_3_n_0 ),
        .O(led_OBUF[1]));
  LUT6 #(
    .INIT(64'h00000CA000000000)) 
    \led_OBUF[1]_inst_i_2 
       (.I0(Q[6]),
        .I1(Q[16]),
        .I2(reg_d1[0]),
        .I3(reg_d1[1]),
        .I4(reg_d0[0]),
        .I5(reg_d0[1]),
        .O(\led_OBUF[1]_inst_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAA888A888A888)) 
    \led_OBUF[2]_inst_i_1 
       (.I0(\led_OBUF[4]_inst_i_2_n_0 ),
        .I1(\led_OBUF[2]_inst_i_2_n_0 ),
        .I2(Q[2]),
        .I3(\led_OBUF[4]_inst_i_4_n_0 ),
        .I4(Q[12]),
        .I5(\led_OBUF[3]_inst_i_3_n_0 ),
        .O(led_OBUF[2]));
  LUT6 #(
    .INIT(64'h00000CA000000000)) 
    \led_OBUF[2]_inst_i_2 
       (.I0(Q[7]),
        .I1(Q[17]),
        .I2(reg_d1[0]),
        .I3(reg_d1[1]),
        .I4(reg_d0[0]),
        .I5(reg_d0[1]),
        .O(\led_OBUF[2]_inst_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAA888A888A888)) 
    \led_OBUF[3]_inst_i_1 
       (.I0(\led_OBUF[4]_inst_i_2_n_0 ),
        .I1(\led_OBUF[3]_inst_i_2_n_0 ),
        .I2(Q[3]),
        .I3(\led_OBUF[4]_inst_i_4_n_0 ),
        .I4(Q[13]),
        .I5(\led_OBUF[3]_inst_i_3_n_0 ),
        .O(led_OBUF[3]));
  LUT6 #(
    .INIT(64'h00000CA000000000)) 
    \led_OBUF[3]_inst_i_2 
       (.I0(Q[8]),
        .I1(Q[18]),
        .I2(reg_d1[0]),
        .I3(reg_d1[1]),
        .I4(reg_d0[0]),
        .I5(reg_d0[1]),
        .O(\led_OBUF[3]_inst_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h0400)) 
    \led_OBUF[3]_inst_i_3 
       (.I0(reg_d0[1]),
        .I1(reg_d0[0]),
        .I2(reg_d1[0]),
        .I3(reg_d1[1]),
        .O(\led_OBUF[3]_inst_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAA888A888A888)) 
    \led_OBUF[4]_inst_i_1 
       (.I0(\led_OBUF[4]_inst_i_2_n_0 ),
        .I1(\led_OBUF[4]_inst_i_3_n_0 ),
        .I2(Q[4]),
        .I3(\led_OBUF[4]_inst_i_4_n_0 ),
        .I4(Q[9]),
        .I5(\led_OBUF[4]_inst_i_5_n_0 ),
        .O(led_OBUF[4]));
  LUT4 #(
    .INIT(16'h0001)) 
    \led_OBUF[4]_inst_i_2 
       (.I0(reg_d1[3]),
        .I1(reg_d1[2]),
        .I2(reg_d0[3]),
        .I3(reg_d0[2]),
        .O(\led_OBUF[4]_inst_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000C000A000000)) 
    \led_OBUF[4]_inst_i_3 
       (.I0(Q[14]),
        .I1(Q[19]),
        .I2(reg_d1[0]),
        .I3(reg_d1[1]),
        .I4(reg_d0[0]),
        .I5(reg_d0[1]),
        .O(\led_OBUF[4]_inst_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h0400)) 
    \led_OBUF[4]_inst_i_4 
       (.I0(reg_d0[1]),
        .I1(reg_d0[0]),
        .I2(reg_d1[1]),
        .I3(reg_d1[0]),
        .O(\led_OBUF[4]_inst_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h0400)) 
    \led_OBUF[4]_inst_i_5 
       (.I0(reg_d1[1]),
        .I1(reg_d1[0]),
        .I2(reg_d0[0]),
        .I3(reg_d0[1]),
        .O(\led_OBUF[4]_inst_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_d0[0]_i_1 
       (.I0(reg_d0[0]),
        .O(\reg_d0[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h6662)) 
    \reg_d0[1]_i_1 
       (.I0(reg_d0[0]),
        .I1(reg_d0[1]),
        .I2(reg_d0[3]),
        .I3(reg_d0[2]),
        .O(\reg_d0[1]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h78)) 
    \reg_d0[2]_i_1 
       (.I0(reg_d0[0]),
        .I1(reg_d0[1]),
        .I2(reg_d0[2]),
        .O(\reg_d0[2]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h4)) 
    \reg_d0[3]_i_1 
       (.I0(start_stop),
        .I1(reset),
        .O(reg_d00));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \reg_d0[3]_i_2 
       (.I0(reg_d0[1]),
        .I1(reg_d0[0]),
        .I2(reg_d0[2]),
        .I3(reg_d0[3]),
        .O(\reg_d0[3]_i_2_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \reg_d0_reg[0] 
       (.C(CLK),
        .CE(start_stop),
        .D(\reg_d0[0]_i_1_n_0 ),
        .Q(reg_d0[0]),
        .S(reg_d00));
  FDRE #(
    .INIT(1'b0)) 
    \reg_d0_reg[1] 
       (.C(CLK),
        .CE(start_stop),
        .D(\reg_d0[1]_i_1_n_0 ),
        .Q(reg_d0[1]),
        .R(reg_d00));
  FDRE #(
    .INIT(1'b0)) 
    \reg_d0_reg[2] 
       (.C(CLK),
        .CE(start_stop),
        .D(\reg_d0[2]_i_1_n_0 ),
        .Q(reg_d0[2]),
        .R(reg_d00));
  FDRE #(
    .INIT(1'b0)) 
    \reg_d0_reg[3] 
       (.C(CLK),
        .CE(start_stop),
        .D(\reg_d0[3]_i_2_n_0 ),
        .Q(reg_d0[3]),
        .R(reg_d00));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_d1[0]_i_1 
       (.I0(reg_d1[0]),
        .O(\reg_d1[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h6662)) 
    \reg_d1[1]_i_1 
       (.I0(reg_d1[0]),
        .I1(reg_d1[1]),
        .I2(reg_d1[3]),
        .I3(reg_d1[2]),
        .O(\reg_d1[1]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h78)) 
    \reg_d1[2]_i_1 
       (.I0(reg_d1[0]),
        .I1(reg_d1[1]),
        .I2(reg_d1[2]),
        .O(\reg_d1[2]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000008)) 
    \reg_d1[3]_i_1 
       (.I0(start_stop),
        .I1(reg_d0[1]),
        .I2(reg_d0[0]),
        .I3(reg_d0[3]),
        .I4(reg_d0[2]),
        .O(\reg_d1[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \reg_d1[3]_i_2 
       (.I0(reg_d1[0]),
        .I1(reg_d1[1]),
        .I2(reg_d1[2]),
        .I3(reg_d1[3]),
        .O(\reg_d1[3]_i_2_n_0 ));
  FDSE #(
    .INIT(1'b1)) 
    \reg_d1_reg[0] 
       (.C(CLK),
        .CE(\reg_d1[3]_i_1_n_0 ),
        .D(\reg_d1[0]_i_1_n_0 ),
        .Q(reg_d1[0]),
        .S(reg_d00));
  FDRE #(
    .INIT(1'b0)) 
    \reg_d1_reg[1] 
       (.C(CLK),
        .CE(\reg_d1[3]_i_1_n_0 ),
        .D(\reg_d1[1]_i_1_n_0 ),
        .Q(reg_d1[1]),
        .R(reg_d00));
  FDRE #(
    .INIT(1'b0)) 
    \reg_d1_reg[2] 
       (.C(CLK),
        .CE(\reg_d1[3]_i_1_n_0 ),
        .D(\reg_d1[2]_i_1_n_0 ),
        .Q(reg_d1[2]),
        .R(reg_d00));
  FDRE #(
    .INIT(1'b0)) 
    \reg_d1_reg[3] 
       (.C(CLK),
        .CE(\reg_d1[3]_i_1_n_0 ),
        .D(\reg_d1[3]_i_2_n_0 ),
        .Q(reg_d1[3]),
        .R(reg_d00));
  LUT2 #(
    .INIT(4'h2)) 
    reset_i_1
       (.I0(reset_n_ff),
        .I1(reset_n_IBUF),
        .O(reset_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    reset_n_ff_reg
       (.C(CLK),
        .CE(1'b1),
        .D(reset_n_IBUF),
        .Q(reset_n_ff),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    reset_reg
       (.C(CLK),
        .CE(1'b1),
        .D(reset_i_1_n_0),
        .Q(reset),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hFFFFFFFF5D5DF555)) 
    \segment_OBUF[4]_inst_i_1 
       (.I0(hex[0]),
        .I1(reg_d1[1]),
        .I2(\segment[4] [0]),
        .I3(reg_d0[1]),
        .I4(\segment[4] [1]),
        .I5(\segment_OBUF[6]_inst_i_3_n_0 ),
        .O(segment_OBUF[1]));
  LUT4 #(
    .INIT(16'h22C0)) 
    \segment_OBUF[4]_inst_i_2 
       (.I0(reg_d1[0]),
        .I1(\segment[4] [0]),
        .I2(reg_d0[0]),
        .I3(\segment[4] [1]),
        .O(hex[0]));
  LUT6 #(
    .INIT(64'hFFFFFFFF5959A555)) 
    \segment_OBUF[5]_inst_i_1 
       (.I0(hex[1]),
        .I1(reg_d1[0]),
        .I2(\segment[4] [0]),
        .I3(reg_d0[0]),
        .I4(\segment[4] [1]),
        .I5(\segment_OBUF[6]_inst_i_3_n_0 ),
        .O(segment_OBUF[2]));
  LUT6 #(
    .INIT(64'hFFFFFFFF5D5DF555)) 
    \segment_OBUF[6]_inst_i_1 
       (.I0(hex[1]),
        .I1(reg_d1[0]),
        .I2(\segment[4] [0]),
        .I3(reg_d0[0]),
        .I4(\segment[4] [1]),
        .I5(\segment_OBUF[6]_inst_i_3_n_0 ),
        .O(segment_OBUF[0]));
  LUT4 #(
    .INIT(16'h22C0)) 
    \segment_OBUF[6]_inst_i_2 
       (.I0(reg_d1[1]),
        .I1(\segment[4] [0]),
        .I2(reg_d0[1]),
        .I3(\segment[4] [1]),
        .O(hex[1]));
  LUT6 #(
    .INIT(64'h0000EEEEFFF00000)) 
    \segment_OBUF[6]_inst_i_3 
       (.I0(reg_d1[2]),
        .I1(reg_d1[3]),
        .I2(reg_d0[2]),
        .I3(reg_d0[3]),
        .I4(\segment[4] [0]),
        .I5(\segment[4] [1]),
        .O(\segment_OBUF[6]_inst_i_3_n_0 ));
  LUT3 #(
    .INIT(8'hB4)) 
    start_stop_inv_i_1
       (.I0(button_n_IBUF),
        .I1(button_n_ff),
        .I2(start_stop),
        .O(start_stop_inv_i_1_n_0));
  (* inverted = "yes" *) 
  FDRE #(
    .INIT(1'b1)) 
    start_stop_reg_inv
       (.C(CLK),
        .CE(1'b1),
        .D(start_stop_inv_i_1_n_0),
        .Q(start_stop),
        .R(1'b0));
endmodule

module enable_sr
   (Q,
    CLK);
  output [3:0]Q;
  input CLK;

  wire CLK;
  wire [3:0]Q;

  FDRE #(
    .INIT(1'b1)) 
    \pattern_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .D(Q[1]),
        .Q(Q[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \pattern_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .D(Q[2]),
        .Q(Q[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b1)) 
    \pattern_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .D(Q[3]),
        .Q(Q[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \pattern_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .D(Q[0]),
        .Q(Q[3]),
        .R(1'b0));
endmodule

module fsm_button
   (load_in_wrapper,
    E,
    load_IBUF,
    clk_IBUF_BUFG,
    reset_n_IBUF,
    Q);
  output load_in_wrapper;
  output [0:0]E;
  input load_IBUF;
  input clk_IBUF_BUFG;
  input reset_n_IBUF;
  input [0:0]Q;

  wire [0:0]E;
  wire [0:0]Q;
  wire button_i_1_n_0;
  wire clk_IBUF_BUFG;
  wire load_IBUF;
  wire load_in_wrapper;
  wire reset_n_IBUF;
  wire state;

  LUT2 #(
    .INIT(4'h8)) 
    \a_reg[7]_i_1 
       (.I0(load_in_wrapper),
        .I1(Q),
        .O(E));
  LUT2 #(
    .INIT(4'h2)) 
    button_i_1
       (.I0(load_IBUF),
        .I1(state),
        .O(button_i_1_n_0));
  FDCE #(
    .INIT(1'b0)) 
    button_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_n_IBUF),
        .D(button_i_1_n_0),
        .Q(load_in_wrapper));
  FDCE #(
    .INIT(1'b0)) 
    state_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .CLR(reset_n_IBUF),
        .D(load_IBUF),
        .Q(state));
endmodule

module mat_wrapper
   (valid_output_OBUF,
    Q,
    \result_out_reg[19]_0 ,
    reset_n_IBUF,
    clk_IBUF_BUFG,
    load_in_wrapper,
    E,
    sw_IBUF);
  output valid_output_OBUF;
  output [0:0]Q;
  output [19:0]\result_out_reg[19]_0 ;
  input reset_n_IBUF;
  input clk_IBUF_BUFG;
  input load_in_wrapper;
  input [0:0]E;
  input [15:0]sw_IBUF;

  wire [0:0]E;
  wire \FSM_onehot_state_reg_n_0_[1] ;
  wire \FSM_onehot_state_reg_n_0_[2] ;
  wire \FSM_onehot_state_reg_n_0_[3] ;
  wire \FSM_onehot_state_reg_n_0_[4] ;
  wire \FSM_onehot_state_reg_n_0_[5] ;
  wire \FSM_onehot_state_reg_n_0_[6] ;
  wire \FSM_onehot_state_reg_n_0_[7] ;
  wire \FSM_onehot_state_reg_n_0_[8] ;
  wire \FSM_onehot_state_reg_n_0_[9] ;
  wire [0:0]Q;
  wire \a_reg_reg_n_0_[0] ;
  wire \a_reg_reg_n_0_[1] ;
  wire \a_reg_reg_n_0_[2] ;
  wire \a_reg_reg_n_0_[3] ;
  wire \a_reg_reg_n_0_[6] ;
  wire \a_reg_reg_n_0_[7] ;
  wire [7:0]b_reg;
  wire clk_IBUF_BUFG;
  wire [1:0]col_in_col0_reg;
  wire [1:0]col_in_col0_reg_2;
  wire [1:0]col_in_col1_reg;
  wire [1:0]col_in_col1_reg_3;
  wire inst_systolic_array_2x2_n_0;
  wire inst_systolic_array_2x2_n_1;
  wire inst_systolic_array_2x2_n_2;
  wire inst_systolic_array_2x2_n_25;
  wire inst_systolic_array_2x2_n_3;
  wire inst_systolic_array_2x2_n_4;
  wire load_in_sys_reg_reg_n_0;
  wire load_in_wrapper;
  wire [1:0]p_0_in_4;
  wire [4:0]\pe00/pe_result_reg ;
  wire [4:0]\pe01/pe_result_reg ;
  wire [4:0]\pe10/pe_result_reg ;
  wire [4:0]\pe11/pe_result_reg ;
  wire reset_n_IBUF;
  wire [19:0]\result_out_reg[19]_0 ;
  wire [1:0]row_in_row0_reg;
  wire [1:0]row_in_row0_reg_0;
  wire [1:0]row_in_row1_reg;
  wire [1:0]row_in_row1_reg_1;
  wire [15:0]sw_IBUF;
  wire valid_output_OBUF;

  (* FSM_ENCODED_STATES = "LOAD_SET2:0000001000,LOAD_UNSET2:0000010000,LOAD_UNSET1:0000000100,LOAD_SET1:0000000010,IDLE:0000000001,WAIT_FOR_DONE:1000000000,LOAD_SET4:0010000000,LOAD_UNSET3:0001000000,LOAD_UNSET4:0100000000,LOAD_SET3:0000100000" *) 
  FDSE #(
    .INIT(1'b1)) 
    \FSM_onehot_state_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_1),
        .D(\FSM_onehot_state_reg_n_0_[9] ),
        .Q(Q),
        .S(reset_n_IBUF));
  (* FSM_ENCODED_STATES = "LOAD_SET2:0000001000,LOAD_UNSET2:0000010000,LOAD_UNSET1:0000000100,LOAD_SET1:0000000010,IDLE:0000000001,WAIT_FOR_DONE:1000000000,LOAD_SET4:0010000000,LOAD_UNSET3:0001000000,LOAD_UNSET4:0100000000,LOAD_SET3:0000100000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_1),
        .D(Q),
        .Q(\FSM_onehot_state_reg_n_0_[1] ),
        .R(reset_n_IBUF));
  (* FSM_ENCODED_STATES = "LOAD_SET2:0000001000,LOAD_UNSET2:0000010000,LOAD_UNSET1:0000000100,LOAD_SET1:0000000010,IDLE:0000000001,WAIT_FOR_DONE:1000000000,LOAD_SET4:0010000000,LOAD_UNSET3:0001000000,LOAD_UNSET4:0100000000,LOAD_SET3:0000100000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_1),
        .D(\FSM_onehot_state_reg_n_0_[1] ),
        .Q(\FSM_onehot_state_reg_n_0_[2] ),
        .R(reset_n_IBUF));
  (* FSM_ENCODED_STATES = "LOAD_SET2:0000001000,LOAD_UNSET2:0000010000,LOAD_UNSET1:0000000100,LOAD_SET1:0000000010,IDLE:0000000001,WAIT_FOR_DONE:1000000000,LOAD_SET4:0010000000,LOAD_UNSET3:0001000000,LOAD_UNSET4:0100000000,LOAD_SET3:0000100000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_1),
        .D(\FSM_onehot_state_reg_n_0_[2] ),
        .Q(\FSM_onehot_state_reg_n_0_[3] ),
        .R(reset_n_IBUF));
  (* FSM_ENCODED_STATES = "LOAD_SET2:0000001000,LOAD_UNSET2:0000010000,LOAD_UNSET1:0000000100,LOAD_SET1:0000000010,IDLE:0000000001,WAIT_FOR_DONE:1000000000,LOAD_SET4:0010000000,LOAD_UNSET3:0001000000,LOAD_UNSET4:0100000000,LOAD_SET3:0000100000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_1),
        .D(\FSM_onehot_state_reg_n_0_[3] ),
        .Q(\FSM_onehot_state_reg_n_0_[4] ),
        .R(reset_n_IBUF));
  (* FSM_ENCODED_STATES = "LOAD_SET2:0000001000,LOAD_UNSET2:0000010000,LOAD_UNSET1:0000000100,LOAD_SET1:0000000010,IDLE:0000000001,WAIT_FOR_DONE:1000000000,LOAD_SET4:0010000000,LOAD_UNSET3:0001000000,LOAD_UNSET4:0100000000,LOAD_SET3:0000100000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_1),
        .D(\FSM_onehot_state_reg_n_0_[4] ),
        .Q(\FSM_onehot_state_reg_n_0_[5] ),
        .R(reset_n_IBUF));
  (* FSM_ENCODED_STATES = "LOAD_SET2:0000001000,LOAD_UNSET2:0000010000,LOAD_UNSET1:0000000100,LOAD_SET1:0000000010,IDLE:0000000001,WAIT_FOR_DONE:1000000000,LOAD_SET4:0010000000,LOAD_UNSET3:0001000000,LOAD_UNSET4:0100000000,LOAD_SET3:0000100000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_1),
        .D(\FSM_onehot_state_reg_n_0_[5] ),
        .Q(\FSM_onehot_state_reg_n_0_[6] ),
        .R(reset_n_IBUF));
  (* FSM_ENCODED_STATES = "LOAD_SET2:0000001000,LOAD_UNSET2:0000010000,LOAD_UNSET1:0000000100,LOAD_SET1:0000000010,IDLE:0000000001,WAIT_FOR_DONE:1000000000,LOAD_SET4:0010000000,LOAD_UNSET3:0001000000,LOAD_UNSET4:0100000000,LOAD_SET3:0000100000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_1),
        .D(\FSM_onehot_state_reg_n_0_[6] ),
        .Q(\FSM_onehot_state_reg_n_0_[7] ),
        .R(reset_n_IBUF));
  (* FSM_ENCODED_STATES = "LOAD_SET2:0000001000,LOAD_UNSET2:0000010000,LOAD_UNSET1:0000000100,LOAD_SET1:0000000010,IDLE:0000000001,WAIT_FOR_DONE:1000000000,LOAD_SET4:0010000000,LOAD_UNSET3:0001000000,LOAD_UNSET4:0100000000,LOAD_SET3:0000100000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_1),
        .D(\FSM_onehot_state_reg_n_0_[7] ),
        .Q(\FSM_onehot_state_reg_n_0_[8] ),
        .R(reset_n_IBUF));
  (* FSM_ENCODED_STATES = "LOAD_SET2:0000001000,LOAD_UNSET2:0000010000,LOAD_UNSET1:0000000100,LOAD_SET1:0000000010,IDLE:0000000001,WAIT_FOR_DONE:1000000000,LOAD_SET4:0010000000,LOAD_UNSET3:0001000000,LOAD_UNSET4:0100000000,LOAD_SET3:0000100000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_1),
        .D(\FSM_onehot_state_reg_n_0_[8] ),
        .Q(\FSM_onehot_state_reg_n_0_[9] ),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[0]),
        .Q(\a_reg_reg_n_0_[0] ),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[1]),
        .Q(\a_reg_reg_n_0_[1] ),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_reg_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[2]),
        .Q(\a_reg_reg_n_0_[2] ),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_reg_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[3]),
        .Q(\a_reg_reg_n_0_[3] ),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_reg_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[4]),
        .Q(p_0_in_4[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_reg_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[5]),
        .Q(p_0_in_4[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_reg_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[6]),
        .Q(\a_reg_reg_n_0_[6] ),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_reg_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[7]),
        .Q(\a_reg_reg_n_0_[7] ),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[8]),
        .Q(b_reg[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[9]),
        .Q(b_reg[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_reg_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[10]),
        .Q(b_reg[2]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_reg_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[11]),
        .Q(b_reg[3]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_reg_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[12]),
        .Q(b_reg[4]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_reg_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[13]),
        .Q(b_reg[5]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_reg_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[14]),
        .Q(b_reg[6]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_reg_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(sw_IBUF[15]),
        .Q(b_reg[7]),
        .R(reset_n_IBUF));
  LUT4 #(
    .INIT(16'hF888)) 
    \col_in_col0_reg[0]_i_1 
       (.I0(b_reg[0]),
        .I1(\FSM_onehot_state_reg_n_0_[3] ),
        .I2(b_reg[4]),
        .I3(\FSM_onehot_state_reg_n_0_[1] ),
        .O(col_in_col0_reg_2[0]));
  LUT4 #(
    .INIT(16'hF888)) 
    \col_in_col0_reg[1]_i_2 
       (.I0(b_reg[1]),
        .I1(\FSM_onehot_state_reg_n_0_[3] ),
        .I2(b_reg[5]),
        .I3(\FSM_onehot_state_reg_n_0_[1] ),
        .O(col_in_col0_reg_2[1]));
  FDRE #(
    .INIT(1'b0)) 
    \col_in_col0_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_4),
        .D(col_in_col0_reg_2[0]),
        .Q(col_in_col0_reg[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \col_in_col0_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_4),
        .D(col_in_col0_reg_2[1]),
        .Q(col_in_col0_reg[1]),
        .R(1'b0));
  LUT4 #(
    .INIT(16'hF888)) 
    \col_in_col1_reg[0]_i_1 
       (.I0(b_reg[2]),
        .I1(\FSM_onehot_state_reg_n_0_[5] ),
        .I2(b_reg[6]),
        .I3(\FSM_onehot_state_reg_n_0_[3] ),
        .O(col_in_col1_reg_3[0]));
  LUT4 #(
    .INIT(16'hF888)) 
    \col_in_col1_reg[1]_i_1 
       (.I0(b_reg[3]),
        .I1(\FSM_onehot_state_reg_n_0_[5] ),
        .I2(b_reg[7]),
        .I3(\FSM_onehot_state_reg_n_0_[3] ),
        .O(col_in_col1_reg_3[1]));
  FDRE #(
    .INIT(1'b0)) 
    \col_in_col1_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_4),
        .D(col_in_col1_reg_3[0]),
        .Q(col_in_col1_reg[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \col_in_col1_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_4),
        .D(col_in_col1_reg_3[1]),
        .Q(col_in_col1_reg[1]),
        .R(1'b0));
  systolic_array_2x2 inst_systolic_array_2x2
       (.E(load_in_sys_reg_reg_n_0),
        .\FSM_onehot_state_reg[0] (inst_systolic_array_2x2_n_2),
        .\FSM_onehot_state_reg[9] (inst_systolic_array_2x2_n_0),
        .\FSM_onehot_state_reg[9]_0 (inst_systolic_array_2x2_n_25),
        .Q({\FSM_onehot_state_reg_n_0_[9] ,\FSM_onehot_state_reg_n_0_[8] ,\FSM_onehot_state_reg_n_0_[7] ,\FSM_onehot_state_reg_n_0_[6] ,\FSM_onehot_state_reg_n_0_[5] ,\FSM_onehot_state_reg_n_0_[4] ,\FSM_onehot_state_reg_n_0_[3] ,\FSM_onehot_state_reg_n_0_[2] ,\FSM_onehot_state_reg_n_0_[1] ,Q}),
        .\a_in_reg_reg[1] (row_in_row0_reg),
        .\a_in_reg_reg[1]_0 (row_in_row1_reg),
        .\b_in_reg_reg[1] (col_in_col0_reg),
        .\b_in_reg_reg[1]_0 (col_in_col1_reg),
        .button_reg(inst_systolic_array_2x2_n_1),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .done_reg_0(inst_systolic_array_2x2_n_4),
        .load_in_wrapper(load_in_wrapper),
        .\pe_result_reg[4] (\pe00/pe_result_reg ),
        .\pe_result_reg[4]_0 (\pe01/pe_result_reg ),
        .\pe_result_reg[4]_1 (\pe10/pe_result_reg ),
        .\pe_result_reg[4]_2 (\pe11/pe_result_reg ),
        .reset_n_IBUF(reset_n_IBUF),
        .valid_op_reg_0(inst_systolic_array_2x2_n_3));
  FDRE #(
    .INIT(1'b0)) 
    load_in_sys_reg_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(inst_systolic_array_2x2_n_25),
        .Q(load_in_sys_reg_reg_n_0),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe00/pe_result_reg [0]),
        .Q(\result_out_reg[19]_0 [0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[10] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe10/pe_result_reg [0]),
        .Q(\result_out_reg[19]_0 [10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[11] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe10/pe_result_reg [1]),
        .Q(\result_out_reg[19]_0 [11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[12] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe10/pe_result_reg [2]),
        .Q(\result_out_reg[19]_0 [12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[13] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe10/pe_result_reg [3]),
        .Q(\result_out_reg[19]_0 [13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[14] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe10/pe_result_reg [4]),
        .Q(\result_out_reg[19]_0 [14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[15] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe11/pe_result_reg [0]),
        .Q(\result_out_reg[19]_0 [15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[16] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe11/pe_result_reg [1]),
        .Q(\result_out_reg[19]_0 [16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[17] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe11/pe_result_reg [2]),
        .Q(\result_out_reg[19]_0 [17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[18] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe11/pe_result_reg [3]),
        .Q(\result_out_reg[19]_0 [18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[19] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe11/pe_result_reg [4]),
        .Q(\result_out_reg[19]_0 [19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe00/pe_result_reg [1]),
        .Q(\result_out_reg[19]_0 [1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe00/pe_result_reg [2]),
        .Q(\result_out_reg[19]_0 [2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe00/pe_result_reg [3]),
        .Q(\result_out_reg[19]_0 [3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe00/pe_result_reg [4]),
        .Q(\result_out_reg[19]_0 [4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[5] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe01/pe_result_reg [0]),
        .Q(\result_out_reg[19]_0 [5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[6] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe01/pe_result_reg [1]),
        .Q(\result_out_reg[19]_0 [6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[7] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe01/pe_result_reg [2]),
        .Q(\result_out_reg[19]_0 [7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[8] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe01/pe_result_reg [3]),
        .Q(\result_out_reg[19]_0 [8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_out_reg[9] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_0),
        .D(\pe01/pe_result_reg [4]),
        .Q(\result_out_reg[19]_0 [9]),
        .R(1'b0));
  LUT4 #(
    .INIT(16'hF888)) 
    \row_in_row0_reg[0]_i_1 
       (.I0(\a_reg_reg_n_0_[0] ),
        .I1(\FSM_onehot_state_reg_n_0_[3] ),
        .I2(\a_reg_reg_n_0_[2] ),
        .I3(\FSM_onehot_state_reg_n_0_[1] ),
        .O(row_in_row0_reg_0[0]));
  LUT4 #(
    .INIT(16'hF888)) 
    \row_in_row0_reg[1]_i_1 
       (.I0(\a_reg_reg_n_0_[1] ),
        .I1(\FSM_onehot_state_reg_n_0_[3] ),
        .I2(\a_reg_reg_n_0_[3] ),
        .I3(\FSM_onehot_state_reg_n_0_[1] ),
        .O(row_in_row0_reg_0[1]));
  FDRE #(
    .INIT(1'b0)) 
    \row_in_row0_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_4),
        .D(row_in_row0_reg_0[0]),
        .Q(row_in_row0_reg[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \row_in_row0_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_4),
        .D(row_in_row0_reg_0[1]),
        .Q(row_in_row0_reg[1]),
        .R(1'b0));
  LUT4 #(
    .INIT(16'hF888)) 
    \row_in_row1_reg[0]_i_1 
       (.I0(p_0_in_4[0]),
        .I1(\FSM_onehot_state_reg_n_0_[5] ),
        .I2(\a_reg_reg_n_0_[6] ),
        .I3(\FSM_onehot_state_reg_n_0_[3] ),
        .O(row_in_row1_reg_1[0]));
  LUT4 #(
    .INIT(16'hF888)) 
    \row_in_row1_reg[1]_i_1 
       (.I0(p_0_in_4[1]),
        .I1(\FSM_onehot_state_reg_n_0_[5] ),
        .I2(\a_reg_reg_n_0_[7] ),
        .I3(\FSM_onehot_state_reg_n_0_[3] ),
        .O(row_in_row1_reg_1[1]));
  FDRE #(
    .INIT(1'b0)) 
    \row_in_row1_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_4),
        .D(row_in_row1_reg_1[0]),
        .Q(row_in_row1_reg[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \row_in_row1_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_4),
        .D(row_in_row1_reg_1[1]),
        .Q(row_in_row1_reg[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    valid_reg
       (.C(clk_IBUF_BUFG),
        .CE(inst_systolic_array_2x2_n_2),
        .D(inst_systolic_array_2x2_n_3),
        .Q(valid_output_OBUF),
        .R(reset_n_IBUF));
endmodule

module pe
   (do_mul_reg_reg_0,
    done_reg,
    done_reg_0,
    Q,
    \row_out_reg[1]_0 ,
    \col_out_reg[1]_0 ,
    reset_n_IBUF,
    E,
    clk_IBUF_BUFG,
    \b_in_reg_reg[1]_0 ,
    \a_in_reg_reg[1]_0 ,
    \result_reg[3] );
  output do_mul_reg_reg_0;
  output done_reg;
  output [0:0]done_reg_0;
  output [4:0]Q;
  output [1:0]\row_out_reg[1]_0 ;
  output [1:0]\col_out_reg[1]_0 ;
  input reset_n_IBUF;
  input [0:0]E;
  input clk_IBUF_BUFG;
  input [1:0]\b_in_reg_reg[1]_0 ;
  input [1:0]\a_in_reg_reg[1]_0 ;
  input [0:0]\result_reg[3] ;

  wire [0:0]E;
  wire [4:0]Q;
  wire [1:0]a_in_reg;
  wire [1:0]\a_in_reg_reg[1]_0 ;
  wire [1:0]b_in_reg;
  wire [1:0]\b_in_reg_reg[1]_0 ;
  wire clk_IBUF_BUFG;
  wire [1:0]\col_out_reg[1]_0 ;
  wire do_mul_reg_reg_0;
  wire done_reg;
  wire [0:0]done_reg_0;
  wire [4:0]p_0_in__0;
  wire \pe11/do_mul_reg ;
  wire reset_n_IBUF;
  wire [0:0]\result_reg[3] ;
  wire [1:0]\row_out_reg[1]_0 ;

  FDRE #(
    .INIT(1'b0)) 
    \a_in_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\a_in_reg_reg[1]_0 [0]),
        .Q(a_in_reg[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_in_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\a_in_reg_reg[1]_0 [1]),
        .Q(a_in_reg[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_in_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\b_in_reg_reg[1]_0 [0]),
        .Q(b_in_reg[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_in_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\b_in_reg_reg[1]_0 [1]),
        .Q(b_in_reg[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \col_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(done_reg_0),
        .D(b_in_reg[0]),
        .Q(\col_out_reg[1]_0 [0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \col_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(done_reg_0),
        .D(b_in_reg[1]),
        .Q(\col_out_reg[1]_0 [1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    do_mul_reg_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(E),
        .Q(\pe11/do_mul_reg ),
        .R(reset_n_IBUF));
  vedic_2x2_21 inst_vedic_2x2
       (.D(p_0_in__0),
        .E(do_mul_reg_reg_0),
        .Q(Q),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .do_mul_reg(\pe11/do_mul_reg ),
        .done_reg_0(done_reg),
        .done_reg_1(done_reg_0),
        .\pe_result_reg[0] (E),
        .reset_n_IBUF(reset_n_IBUF),
        .\result_out_reg[1] (b_in_reg),
        .\result_out_reg[1]_0 (a_in_reg),
        .\result_reg[3]_0 (\result_reg[3] ));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(done_reg_0),
        .D(p_0_in__0[0]),
        .Q(Q[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(done_reg_0),
        .D(p_0_in__0[1]),
        .Q(Q[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(done_reg_0),
        .D(p_0_in__0[2]),
        .Q(Q[2]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(done_reg_0),
        .D(p_0_in__0[3]),
        .Q(Q[3]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(done_reg_0),
        .D(p_0_in__0[4]),
        .Q(Q[4]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \row_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(done_reg_0),
        .D(a_in_reg[0]),
        .Q(\row_out_reg[1]_0 [0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \row_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(done_reg_0),
        .D(a_in_reg[1]),
        .Q(\row_out_reg[1]_0 [1]),
        .R(reset_n_IBUF));
endmodule

(* ORIG_REF_NAME = "pe" *) 
module pe_0
   (Q,
    \col_out_reg[1]_0 ,
    \result_out_reg[0] ,
    clk_IBUF_BUFG,
    \result_out_reg[0]_0 ,
    reset_n_IBUF,
    E,
    \b_in_reg_reg[1]_0 ,
    D,
    \pe_result_reg[4]_0 ,
    \result_reg[0] );
  output [4:0]Q;
  output [1:0]\col_out_reg[1]_0 ;
  input \result_out_reg[0] ;
  input clk_IBUF_BUFG;
  input \result_out_reg[0]_0 ;
  input reset_n_IBUF;
  input [0:0]E;
  input [1:0]\b_in_reg_reg[1]_0 ;
  input [1:0]D;
  input [0:0]\pe_result_reg[4]_0 ;
  input [0:0]\result_reg[0] ;

  wire [1:0]D;
  wire [0:0]E;
  wire [4:0]Q;
  wire [1:0]a_in_reg;
  wire [1:0]b_in_reg;
  wire [1:0]\b_in_reg_reg[1]_0 ;
  wire clk_IBUF_BUFG;
  wire [1:0]\col_out_reg[1]_0 ;
  wire [4:0]p_0_in__1;
  wire [0:0]\pe_result_reg[4]_0 ;
  wire reset_n_IBUF;
  wire \result_out_reg[0] ;
  wire \result_out_reg[0]_0 ;
  wire [0:0]\result_reg[0] ;

  FDRE #(
    .INIT(1'b0)) 
    \a_in_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[0]),
        .Q(a_in_reg[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_in_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[1]),
        .Q(a_in_reg[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_in_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\b_in_reg_reg[1]_0 [0]),
        .Q(b_in_reg[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_in_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\b_in_reg_reg[1]_0 [1]),
        .Q(b_in_reg[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \col_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(b_in_reg[0]),
        .Q(\col_out_reg[1]_0 [0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \col_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(b_in_reg[1]),
        .Q(\col_out_reg[1]_0 [1]),
        .R(reset_n_IBUF));
  vedic_2x2_14 inst_vedic_2x2
       (.D(p_0_in__1),
        .Q(Q),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\result_out_reg[0] (\result_out_reg[0] ),
        .\result_out_reg[0]_0 (\result_out_reg[0]_0 ),
        .\result_out_reg[1] (b_in_reg),
        .\result_out_reg[1]_0 (a_in_reg),
        .\result_reg[0]_0 (\result_reg[0] ));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__1[0]),
        .Q(Q[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__1[1]),
        .Q(Q[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__1[2]),
        .Q(Q[2]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__1[3]),
        .Q(Q[3]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__1[4]),
        .Q(Q[4]),
        .R(reset_n_IBUF));
endmodule

(* ORIG_REF_NAME = "pe" *) 
module pe_1
   (Q,
    \row_out_reg[1]_0 ,
    \result_out_reg[0] ,
    clk_IBUF_BUFG,
    \result_out_reg[0]_0 ,
    reset_n_IBUF,
    E,
    D,
    \a_in_reg_reg[1]_0 ,
    \pe_result_reg[4]_0 ,
    \result_reg[3] );
  output [4:0]Q;
  output [1:0]\row_out_reg[1]_0 ;
  input \result_out_reg[0] ;
  input clk_IBUF_BUFG;
  input \result_out_reg[0]_0 ;
  input reset_n_IBUF;
  input [0:0]E;
  input [1:0]D;
  input [1:0]\a_in_reg_reg[1]_0 ;
  input [0:0]\pe_result_reg[4]_0 ;
  input [0:0]\result_reg[3] ;

  wire [1:0]D;
  wire [0:0]E;
  wire [4:0]Q;
  wire [1:0]a_in_reg;
  wire [1:0]\a_in_reg_reg[1]_0 ;
  wire [1:0]b_in_reg;
  wire clk_IBUF_BUFG;
  wire [4:0]p_0_in__2;
  wire [0:0]\pe_result_reg[4]_0 ;
  wire reset_n_IBUF;
  wire \result_out_reg[0] ;
  wire \result_out_reg[0]_0 ;
  wire [0:0]\result_reg[3] ;
  wire [1:0]\row_out_reg[1]_0 ;

  FDRE #(
    .INIT(1'b0)) 
    \a_in_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\a_in_reg_reg[1]_0 [0]),
        .Q(a_in_reg[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_in_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\a_in_reg_reg[1]_0 [1]),
        .Q(a_in_reg[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_in_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[0]),
        .Q(b_in_reg[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_in_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[1]),
        .Q(b_in_reg[1]),
        .R(reset_n_IBUF));
  vedic_2x2_7 inst_vedic_2x2
       (.D(p_0_in__2),
        .Q(Q),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\result_out_reg[0] (\result_out_reg[0] ),
        .\result_out_reg[0]_0 (\result_out_reg[0]_0 ),
        .\result_out_reg[1] (b_in_reg),
        .\result_out_reg[1]_0 (a_in_reg),
        .\result_reg[3]_0 (\result_reg[3] ));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__2[0]),
        .Q(Q[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__2[1]),
        .Q(Q[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__2[2]),
        .Q(Q[2]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__2[3]),
        .Q(Q[3]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__2[4]),
        .Q(Q[4]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \row_out_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(a_in_reg[0]),
        .Q(\row_out_reg[1]_0 [0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \row_out_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(a_in_reg[1]),
        .Q(\row_out_reg[1]_0 [1]),
        .R(reset_n_IBUF));
endmodule

(* ORIG_REF_NAME = "pe" *) 
module pe_2
   (pe11_done,
    \count_reg[0] ,
    reset_n,
    Q,
    done_pe_reg_0,
    done_pe_reg_1,
    done_pe_reg_2,
    \result_out_reg[0] ,
    clk_IBUF_BUFG,
    \result_out_reg[0]_0 ,
    reset_n_IBUF,
    \pe_result_reg[4]_0 ,
    valid_op_reg,
    valid_op_reg_0,
    valid_op_reg_1,
    done_sys,
    done01_reg,
    done11,
    done00_reg,
    E,
    D,
    \a_in_reg_reg[1]_0 );
  output pe11_done;
  output \count_reg[0] ;
  output [0:0]reset_n;
  output [4:0]Q;
  output done_pe_reg_0;
  output done_pe_reg_1;
  output done_pe_reg_2;
  input \result_out_reg[0] ;
  input clk_IBUF_BUFG;
  input \result_out_reg[0]_0 ;
  input reset_n_IBUF;
  input [0:0]\pe_result_reg[4]_0 ;
  input valid_op_reg;
  input valid_op_reg_0;
  input valid_op_reg_1;
  input done_sys;
  input done01_reg;
  input done11;
  input done00_reg;
  input [0:0]E;
  input [1:0]D;
  input [1:0]\a_in_reg_reg[1]_0 ;

  wire [1:0]D;
  wire [0:0]E;
  wire [4:0]Q;
  wire [1:0]a_in_reg;
  wire [1:0]\a_in_reg_reg[1]_0 ;
  wire [1:0]b_in_reg;
  wire clk_IBUF_BUFG;
  wire \count_reg[0] ;
  wire done00_reg;
  wire done01_reg;
  wire done11;
  wire done_pe_reg_0;
  wire done_pe_reg_1;
  wire done_pe_reg_2;
  wire done_sys;
  wire [4:0]p_0_in__3;
  wire pe11_done;
  wire [0:0]\pe_result_reg[4]_0 ;
  wire [0:0]reset_n;
  wire reset_n_IBUF;
  wire \result_out_reg[0] ;
  wire \result_out_reg[0]_0 ;
  wire valid_op_reg;
  wire valid_op_reg_0;
  wire valid_op_reg_1;

  FDRE #(
    .INIT(1'b0)) 
    \a_in_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\a_in_reg_reg[1]_0 [0]),
        .Q(a_in_reg[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \a_in_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(\a_in_reg_reg[1]_0 [1]),
        .Q(a_in_reg[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_in_reg_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[0]),
        .Q(b_in_reg[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \b_in_reg_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(D[1]),
        .Q(b_in_reg[1]),
        .R(reset_n_IBUF));
  LUT3 #(
    .INIT(8'hBA)) 
    done00_i_1
       (.I0(pe11_done),
        .I1(done_sys),
        .I2(done00_reg),
        .O(done_pe_reg_2));
  (* \PinAttr:I2:HOLD_DETOUR  = "182" *) 
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hBA)) 
    done01_i_1
       (.I0(pe11_done),
        .I1(done_sys),
        .I2(done01_reg),
        .O(done_pe_reg_0));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hBA)) 
    done11_i_1
       (.I0(pe11_done),
        .I1(done_sys),
        .I2(done11),
        .O(done_pe_reg_1));
  FDRE #(
    .INIT(1'b0)) 
    done_pe_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\pe_result_reg[4]_0 ),
        .Q(pe11_done),
        .R(reset_n_IBUF));
  vedic_2x2 inst_vedic_2x2
       (.D(p_0_in__3),
        .E(reset_n),
        .Q(Q),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .reset_n_IBUF(reset_n_IBUF),
        .\result_out_reg[0] (\result_out_reg[0] ),
        .\result_out_reg[0]_0 (\result_out_reg[0]_0 ),
        .\result_out_reg[1] (b_in_reg),
        .\result_out_reg[1]_0 (a_in_reg));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__3[0]),
        .Q(Q[0]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__3[1]),
        .Q(Q[1]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__3[2]),
        .Q(Q[2]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__3[3]),
        .Q(Q[3]),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \pe_result_reg[4] 
       (.C(clk_IBUF_BUFG),
        .CE(\pe_result_reg[4]_0 ),
        .D(p_0_in__3[4]),
        .Q(Q[4]),
        .R(reset_n_IBUF));
  LUT5 #(
    .INIT(32'h00000010)) 
    valid_op_i_1
       (.I0(valid_op_reg),
        .I1(valid_op_reg_0),
        .I2(valid_op_reg_1),
        .I3(pe11_done),
        .I4(reset_n_IBUF),
        .O(\count_reg[0] ));
endmodule

module systolic_array_2x2
   (\FSM_onehot_state_reg[9] ,
    button_reg,
    \FSM_onehot_state_reg[0] ,
    valid_op_reg_0,
    done_reg_0,
    \pe_result_reg[4] ,
    \pe_result_reg[4]_0 ,
    \pe_result_reg[4]_1 ,
    \pe_result_reg[4]_2 ,
    \FSM_onehot_state_reg[9]_0 ,
    reset_n_IBUF,
    E,
    clk_IBUF_BUFG,
    Q,
    load_in_wrapper,
    \b_in_reg_reg[1] ,
    \a_in_reg_reg[1] ,
    \b_in_reg_reg[1]_0 ,
    \a_in_reg_reg[1]_0 );
  output [0:0]\FSM_onehot_state_reg[9] ;
  output [0:0]button_reg;
  output \FSM_onehot_state_reg[0] ;
  output valid_op_reg_0;
  output [0:0]done_reg_0;
  output [4:0]\pe_result_reg[4] ;
  output [4:0]\pe_result_reg[4]_0 ;
  output [4:0]\pe_result_reg[4]_1 ;
  output [4:0]\pe_result_reg[4]_2 ;
  output \FSM_onehot_state_reg[9]_0 ;
  input reset_n_IBUF;
  input [0:0]E;
  input clk_IBUF_BUFG;
  input [9:0]Q;
  input load_in_wrapper;
  input [1:0]\b_in_reg_reg[1] ;
  input [1:0]\a_in_reg_reg[1] ;
  input [1:0]\b_in_reg_reg[1]_0 ;
  input [1:0]\a_in_reg_reg[1]_0 ;

  wire [0:0]E;
  wire \FSM_onehot_state[9]_i_2_n_0 ;
  wire \FSM_onehot_state_reg[0] ;
  wire [0:0]\FSM_onehot_state_reg[9] ;
  wire \FSM_onehot_state_reg[9]_0 ;
  wire [9:0]Q;
  wire [1:0]\a_in_reg_reg[1] ;
  wire [1:0]\a_in_reg_reg[1]_0 ;
  wire [1:0]\b_in_reg_reg[1] ;
  wire [1:0]\b_in_reg_reg[1]_0 ;
  wire [0:0]button_reg;
  wire clk_IBUF_BUFG;
  wire [1:0]col_out;
  wire \count[0]_i_1_n_0 ;
  wire \count[1]_i_1_n_0 ;
  wire \count[2]_i_1_n_0 ;
  wire \count_reg_n_0_[0] ;
  wire \count_reg_n_0_[1] ;
  wire \count_reg_n_0_[2] ;
  wire done0;
  wire done00_reg_n_0;
  wire done01_reg_n_0;
  wire done11;
  wire [0:0]done_reg_0;
  wire done_sys;
  wire load_in_sys_reg;
  wire load_in_wrapper;
  wire pe00_n_0;
  wire pe00_n_1;
  wire pe00_n_2;
  wire pe01_n_5;
  wire pe01_n_6;
  wire pe10_n_5;
  wire pe10_n_6;
  wire pe11_done;
  wire pe11_n_1;
  wire pe11_n_10;
  wire pe11_n_2;
  wire pe11_n_8;
  wire pe11_n_9;
  wire [4:0]\pe_result_reg[4] ;
  wire [4:0]\pe_result_reg[4]_0 ;
  wire [4:0]\pe_result_reg[4]_1 ;
  wire [4:0]\pe_result_reg[4]_2 ;
  wire reset_n_IBUF;
  wire [1:0]row_out;
  wire valid_op;
  wire valid_op_reg_0;

  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \FSM_onehot_state[9]_i_1 
       (.I0(load_in_wrapper),
        .I1(Q[0]),
        .I2(valid_op),
        .I3(Q[9]),
        .I4(\FSM_onehot_state[9]_i_2_n_0 ),
        .O(button_reg));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \FSM_onehot_state[9]_i_2 
       (.I0(load_in_sys_reg),
        .I1(Q[8]),
        .I2(Q[2]),
        .I3(Q[6]),
        .I4(Q[4]),
        .O(\FSM_onehot_state[9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFAAA8)) 
    \col_in_col0_reg[1]_i_1 
       (.I0(done_sys),
        .I1(Q[5]),
        .I2(Q[3]),
        .I3(Q[7]),
        .I4(Q[1]),
        .I5(reset_n_IBUF),
        .O(done_reg_0));
  LUT2 #(
    .INIT(4'h6)) 
    \count[0]_i_1 
       (.I0(pe11_done),
        .I1(\count_reg_n_0_[0] ),
        .O(\count[0]_i_1_n_0 ));
  (* \PinAttr:I2:HOLD_DETOUR  = "193" *) 
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \count[1]_i_1 
       (.I0(pe11_done),
        .I1(\count_reg_n_0_[0] ),
        .I2(\count_reg_n_0_[1] ),
        .O(\count[1]_i_1_n_0 ));
  (* \PinAttr:I2:HOLD_DETOUR  = "193" *) 
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT4 #(
    .INIT(16'h7E80)) 
    \count[2]_i_1 
       (.I0(pe11_done),
        .I1(\count_reg_n_0_[0] ),
        .I2(\count_reg_n_0_[1] ),
        .I3(\count_reg_n_0_[2] ),
        .O(\count[2]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count[0]_i_1_n_0 ),
        .Q(\count_reg_n_0_[0] ),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count[1]_i_1_n_0 ),
        .Q(\count_reg_n_0_[1] ),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    \count_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(\count[2]_i_1_n_0 ),
        .Q(\count_reg_n_0_[2] ),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    done00_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(pe11_n_10),
        .Q(done00_reg_n_0),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    done01_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(pe11_n_8),
        .Q(done01_reg_n_0),
        .R(reset_n_IBUF));
  FDRE #(
    .INIT(1'b0)) 
    done11_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(pe11_n_9),
        .Q(done11),
        .R(reset_n_IBUF));
  LUT4 #(
    .INIT(16'h0080)) 
    done_i_1
       (.I0(done00_reg_n_0),
        .I1(done01_reg_n_0),
        .I2(done11),
        .I3(done_sys),
        .O(done0));
  FDRE #(
    .INIT(1'b0)) 
    done_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(done0),
        .Q(done_sys),
        .R(reset_n_IBUF));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT4 #(
    .INIT(16'hABA8)) 
    load_in_sys_reg_i_1
       (.I0(load_in_sys_reg),
        .I1(Q[9]),
        .I2(\FSM_onehot_state[9]_i_2_n_0 ),
        .I3(E),
        .O(\FSM_onehot_state_reg[9]_0 ));
  LUT5 #(
    .INIT(32'hFFFEAAAA)) 
    load_in_sys_reg_i_2
       (.I0(Q[1]),
        .I1(Q[7]),
        .I2(Q[3]),
        .I3(Q[5]),
        .I4(done_sys),
        .O(load_in_sys_reg));
  pe pe00
       (.E(E),
        .Q(\pe_result_reg[4] ),
        .\a_in_reg_reg[1]_0 (\a_in_reg_reg[1] ),
        .\b_in_reg_reg[1]_0 (\b_in_reg_reg[1] ),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\col_out_reg[1]_0 (col_out),
        .do_mul_reg_reg_0(pe00_n_0),
        .done_reg(pe00_n_1),
        .done_reg_0(pe00_n_2),
        .reset_n_IBUF(reset_n_IBUF),
        .\result_reg[3] (pe11_n_2),
        .\row_out_reg[1]_0 (row_out));
  pe_0 pe01
       (.D(row_out),
        .E(E),
        .Q(\pe_result_reg[4]_0 ),
        .\b_in_reg_reg[1]_0 (\b_in_reg_reg[1]_0 ),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\col_out_reg[1]_0 ({pe01_n_5,pe01_n_6}),
        .\pe_result_reg[4]_0 (pe00_n_2),
        .reset_n_IBUF(reset_n_IBUF),
        .\result_out_reg[0] (pe00_n_0),
        .\result_out_reg[0]_0 (pe00_n_1),
        .\result_reg[0] (pe11_n_2));
  pe_1 pe10
       (.D(col_out),
        .E(E),
        .Q(\pe_result_reg[4]_1 ),
        .\a_in_reg_reg[1]_0 (\a_in_reg_reg[1]_0 ),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\pe_result_reg[4]_0 (pe00_n_2),
        .reset_n_IBUF(reset_n_IBUF),
        .\result_out_reg[0] (pe00_n_0),
        .\result_out_reg[0]_0 (pe00_n_1),
        .\result_reg[3] (pe11_n_2),
        .\row_out_reg[1]_0 ({pe10_n_5,pe10_n_6}));
  pe_2 pe11
       (.D({pe01_n_5,pe01_n_6}),
        .E(E),
        .Q(\pe_result_reg[4]_2 ),
        .\a_in_reg_reg[1]_0 ({pe10_n_5,pe10_n_6}),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\count_reg[0] (pe11_n_1),
        .done00_reg(done00_reg_n_0),
        .done01_reg(done01_reg_n_0),
        .done11(done11),
        .done_pe_reg_0(pe11_n_8),
        .done_pe_reg_1(pe11_n_9),
        .done_pe_reg_2(pe11_n_10),
        .done_sys(done_sys),
        .pe11_done(pe11_done),
        .\pe_result_reg[4]_0 (pe00_n_2),
        .reset_n(pe11_n_2),
        .reset_n_IBUF(reset_n_IBUF),
        .\result_out_reg[0] (pe00_n_0),
        .\result_out_reg[0]_0 (pe00_n_1),
        .valid_op_reg(\count_reg_n_0_[0] ),
        .valid_op_reg_0(\count_reg_n_0_[1] ),
        .valid_op_reg_1(\count_reg_n_0_[2] ));
  LUT3 #(
    .INIT(8'h08)) 
    \result_out[19]_i_1 
       (.I0(Q[9]),
        .I1(valid_op),
        .I2(reset_n_IBUF),
        .O(\FSM_onehot_state_reg[9] ));
  LUT3 #(
    .INIT(8'hEA)) 
    valid_i_1
       (.I0(Q[0]),
        .I1(Q[9]),
        .I2(valid_op),
        .O(\FSM_onehot_state_reg[0] ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT2 #(
    .INIT(4'h8)) 
    valid_i_2
       (.I0(valid_op),
        .I1(Q[9]),
        .O(valid_op_reg_0));
  FDRE #(
    .INIT(1'b0)) 
    valid_op_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(pe11_n_1),
        .Q(valid_op),
        .R(1'b0));
endmodule

(* ECO_CHECKSUM = "56ace7a0" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module top
   (clk,
    button_n,
    reset_n,
    sw,
    segment,
    enable_D1,
    enable_D2,
    enable_D3,
    enable_D4,
    load,
    valid_output,
    led);
  input clk;
  input button_n;
  input reset_n;
  input [15:0]sw;
  output [6:0]segment;
  output enable_D1;
  output enable_D2;
  output enable_D3;
  output enable_D4;
  input load;
  output valid_output;
  output [4:0]led;

  wire a_reg;
  wire button_n;
  wire button_n_IBUF;
  wire clk;
  wire clk_IBUF;
  wire clk_IBUF_BUFG;
  wire [4:0]data1;
  wire [4:0]data2;
  wire [4:0]data3;
  wire enable_D1;
  wire enable_D1_OBUF;
  wire enable_D2;
  wire enable_D2_OBUF;
  wire enable_D3;
  wire enable_D3_OBUF;
  wire enable_D4;
  wire enable_D4_OBUF;
  wire inst_wrapper_n_1;
  wire inst_wrapper_n_17;
  wire inst_wrapper_n_18;
  wire inst_wrapper_n_19;
  wire inst_wrapper_n_20;
  wire inst_wrapper_n_21;
  wire [4:0]led;
  wire [4:0]led_OBUF;
  wire load;
  wire load_IBUF;
  wire load_in_wrapper;
  wire rclk;
  wire reset_n;
  wire reset_n_IBUF;
  wire [6:0]segment;
  wire [5:0]segment_OBUF;
  wire [15:0]sw;
  wire [15:0]sw_IBUF;
  wire tmp_clk;
  wire valid_output;
  wire valid_output_OBUF;

  clkgen Uclkgen
       (.CLK(rclk),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .tmp_clk_reg_0(tmp_clk));
  counter Ucounter
       (.CLK(tmp_clk),
        .Q({data3,data2,data1,inst_wrapper_n_17,inst_wrapper_n_18,inst_wrapper_n_19,inst_wrapper_n_20,inst_wrapper_n_21}),
        .button_n_IBUF(button_n_IBUF),
        .led_OBUF(led_OBUF),
        .reset_n_IBUF(reset_n_IBUF),
        .\segment[4] ({enable_D1_OBUF,enable_D2_OBUF}),
        .segment_OBUF({segment_OBUF[5:4],segment_OBUF[0]}));
  enable_sr Uenable
       (.CLK(rclk),
        .Q({enable_D1_OBUF,enable_D2_OBUF,enable_D3_OBUF,enable_D4_OBUF}));
  IBUF button_n_IBUF_inst
       (.I(button_n),
        .O(button_n_IBUF));
  BUFG clk_IBUF_BUFG_inst
       (.I(clk_IBUF),
        .O(clk_IBUF_BUFG));
  IBUF clk_IBUF_inst
       (.I(clk),
        .O(clk_IBUF));
  OBUF enable_D1_OBUF_inst
       (.I(enable_D1_OBUF),
        .O(enable_D1));
  OBUF enable_D2_OBUF_inst
       (.I(enable_D2_OBUF),
        .O(enable_D2));
  OBUF enable_D3_OBUF_inst
       (.I(enable_D3_OBUF),
        .O(enable_D3));
  OBUF enable_D4_OBUF_inst
       (.I(enable_D4_OBUF),
        .O(enable_D4));
  fsm_button inst
       (.E(a_reg),
        .Q(inst_wrapper_n_1),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .load_IBUF(load_IBUF),
        .load_in_wrapper(load_in_wrapper),
        .reset_n_IBUF(reset_n_IBUF));
  mat_wrapper inst_wrapper
       (.E(a_reg),
        .Q(inst_wrapper_n_1),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .load_in_wrapper(load_in_wrapper),
        .reset_n_IBUF(reset_n_IBUF),
        .\result_out_reg[19]_0 ({data3,data2,data1,inst_wrapper_n_17,inst_wrapper_n_18,inst_wrapper_n_19,inst_wrapper_n_20,inst_wrapper_n_21}),
        .sw_IBUF(sw_IBUF),
        .valid_output_OBUF(valid_output_OBUF));
  OBUF \led_OBUF[0]_inst 
       (.I(led_OBUF[0]),
        .O(led[0]));
  OBUF \led_OBUF[1]_inst 
       (.I(led_OBUF[1]),
        .O(led[1]));
  OBUF \led_OBUF[2]_inst 
       (.I(led_OBUF[2]),
        .O(led[2]));
  OBUF \led_OBUF[3]_inst 
       (.I(led_OBUF[3]),
        .O(led[3]));
  OBUF \led_OBUF[4]_inst 
       (.I(led_OBUF[4]),
        .O(led[4]));
  IBUF load_IBUF_inst
       (.I(load),
        .O(load_IBUF));
  IBUF reset_n_IBUF_inst
       (.I(reset_n),
        .O(reset_n_IBUF));
  OBUF \segment_OBUF[0]_inst 
       (.I(segment_OBUF[0]),
        .O(segment[0]));
  OBUF \segment_OBUF[1]_inst 
       (.I(1'b1),
        .O(segment[1]));
  OBUF \segment_OBUF[2]_inst 
       (.I(segment_OBUF[0]),
        .O(segment[2]));
  OBUF \segment_OBUF[3]_inst 
       (.I(segment_OBUF[0]),
        .O(segment[3]));
  OBUF \segment_OBUF[4]_inst 
       (.I(segment_OBUF[4]),
        .O(segment[4]));
  OBUF \segment_OBUF[5]_inst 
       (.I(segment_OBUF[5]),
        .O(segment[5]));
  OBUF \segment_OBUF[6]_inst 
       (.I(segment_OBUF[0]),
        .O(segment[6]));
  IBUF \sw_IBUF[0]_inst 
       (.I(sw[0]),
        .O(sw_IBUF[0]));
  IBUF \sw_IBUF[10]_inst 
       (.I(sw[10]),
        .O(sw_IBUF[10]));
  IBUF \sw_IBUF[11]_inst 
       (.I(sw[11]),
        .O(sw_IBUF[11]));
  IBUF \sw_IBUF[12]_inst 
       (.I(sw[12]),
        .O(sw_IBUF[12]));
  IBUF \sw_IBUF[13]_inst 
       (.I(sw[13]),
        .O(sw_IBUF[13]));
  IBUF \sw_IBUF[14]_inst 
       (.I(sw[14]),
        .O(sw_IBUF[14]));
  IBUF \sw_IBUF[15]_inst 
       (.I(sw[15]),
        .O(sw_IBUF[15]));
  IBUF \sw_IBUF[1]_inst 
       (.I(sw[1]),
        .O(sw_IBUF[1]));
  IBUF \sw_IBUF[2]_inst 
       (.I(sw[2]),
        .O(sw_IBUF[2]));
  IBUF \sw_IBUF[3]_inst 
       (.I(sw[3]),
        .O(sw_IBUF[3]));
  IBUF \sw_IBUF[4]_inst 
       (.I(sw[4]),
        .O(sw_IBUF[4]));
  IBUF \sw_IBUF[5]_inst 
       (.I(sw[5]),
        .O(sw_IBUF[5]));
  IBUF \sw_IBUF[6]_inst 
       (.I(sw[6]),
        .O(sw_IBUF[6]));
  IBUF \sw_IBUF[7]_inst 
       (.I(sw[7]),
        .O(sw_IBUF[7]));
  IBUF \sw_IBUF[8]_inst 
       (.I(sw[8]),
        .O(sw_IBUF[8]));
  IBUF \sw_IBUF[9]_inst 
       (.I(sw[9]),
        .O(sw_IBUF[9]));
  OBUF valid_output_OBUF_inst
       (.I(valid_output_OBUF),
        .O(valid_output));
endmodule

module vedic_2x2
   (E,
    D,
    \result_out_reg[0] ,
    clk_IBUF_BUFG,
    \result_out_reg[0]_0 ,
    reset_n_IBUF,
    Q,
    \result_out_reg[1] ,
    \result_out_reg[1]_0 );
  output [0:0]E;
  output [4:0]D;
  input \result_out_reg[0] ;
  input clk_IBUF_BUFG;
  input \result_out_reg[0]_0 ;
  input reset_n_IBUF;
  input [4:0]Q;
  input [1:0]\result_out_reg[1] ;
  input [1:0]\result_out_reg[1]_0 ;

  wire B0_n_0;
  wire B1_n_0;
  wire B2_n_0;
  wire B3_n_0;
  wire [4:0]D;
  wire [0:0]E;
  wire H0_n_0;
  wire H0_n_1;
  wire H1_n_0;
  wire H1_n_1;
  wire [4:0]Q;
  wire clk_IBUF_BUFG;
  wire \pe_result[4]_i_2__2_n_0 ;
  wire reset_n_IBUF;
  wire \result_out_reg[0] ;
  wire \result_out_reg[0]_0 ;
  wire [1:0]\result_out_reg[1] ;
  wire [1:0]\result_out_reg[1]_0 ;
  wire \result_reg_n_0_[0] ;
  wire \result_reg_n_0_[1] ;
  wire \result_reg_n_0_[2] ;
  wire \result_reg_n_0_[3] ;

  PIPO B0
       (.D(B0_n_0),
        .Q(H0_n_1),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (\result_out_reg[0]_0 ));
  PIPO_3 B1
       (.clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (B1_n_0),
        .\d_out_reg[0]_1 (\result_out_reg[0] ),
        .\d_out_reg[0]_2 (\result_out_reg[1]_0 [1]),
        .\d_out_reg[0]_3 (\result_out_reg[1] [1]));
  PIPO_4 B2
       (.clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (B2_n_0),
        .\d_out_reg[0]_1 (\result_out_reg[0] ),
        .\d_out_reg[0]_2 (\result_out_reg[1]_0 [0]),
        .\d_out_reg[0]_3 (\result_out_reg[1] [0]));
  PIPO_5 B3
       (.D(B3_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (\result_out_reg[0]_0 ),
        .\d_out_reg[0]_1 (B2_n_0));
  adder H0
       (.Q({H0_n_0,H0_n_1}),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\result_out_reg[0]_0 (\result_out_reg[0] ),
        .\result_out_reg[1]_0 (\result_out_reg[1] ),
        .\result_out_reg[1]_1 (\result_out_reg[1]_0 ));
  adder_6 H1
       (.Q(H0_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\result_out_reg[0]_0 (B1_n_0),
        .\result_out_reg[0]_1 (\result_out_reg[0]_0 ),
        .\result_out_reg[1]_0 ({H1_n_0,H1_n_1}));
  (* \PinAttr:I1:HOLD_DETOUR  = "193" *) 
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \pe_result[0]_i_1__2 
       (.I0(\result_reg_n_0_[0] ),
        .I1(Q[0]),
        .O(D[0]));
  (* \PinAttr:I0:HOLD_DETOUR  = "193" *) 
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT4 #(
    .INIT(16'h8778)) 
    \pe_result[1]_i_1__2 
       (.I0(Q[0]),
        .I1(\result_reg_n_0_[0] ),
        .I2(Q[1]),
        .I3(\result_reg_n_0_[1] ),
        .O(D[1]));
  LUT6 #(
    .INIT(64'hE88817771777E888)) 
    \pe_result[2]_i_1__2 
       (.I0(\result_reg_n_0_[1] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(\result_reg_n_0_[0] ),
        .I4(Q[2]),
        .I5(\result_reg_n_0_[2] ),
        .O(D[2]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \pe_result[3]_i_1__2 
       (.I0(\pe_result[4]_i_2__2_n_0 ),
        .I1(Q[3]),
        .I2(\result_reg_n_0_[3] ),
        .O(D[3]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT4 #(
    .INIT(16'h65A6)) 
    \pe_result[4]_i_1__2 
       (.I0(Q[4]),
        .I1(\result_reg_n_0_[3] ),
        .I2(\pe_result[4]_i_2__2_n_0 ),
        .I3(Q[3]),
        .O(D[4]));
  LUT6 #(
    .INIT(64'h00151555557F7FFF)) 
    \pe_result[4]_i_2__2 
       (.I0(\result_reg_n_0_[2] ),
        .I1(\result_reg_n_0_[0] ),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(\result_reg_n_0_[1] ),
        .I5(Q[2]),
        .O(\pe_result[4]_i_2__2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \result[3]_i_1 
       (.I0(reset_n_IBUF),
        .O(E));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(B3_n_0),
        .Q(\result_reg_n_0_[0] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(B0_n_0),
        .Q(\result_reg_n_0_[1] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(H1_n_1),
        .Q(\result_reg_n_0_[2] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(E),
        .D(H1_n_0),
        .Q(\result_reg_n_0_[3] ),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "vedic_2x2" *) 
module vedic_2x2_14
   (D,
    \result_out_reg[0] ,
    clk_IBUF_BUFG,
    \result_out_reg[0]_0 ,
    Q,
    \result_reg[0]_0 ,
    \result_out_reg[1] ,
    \result_out_reg[1]_0 );
  output [4:0]D;
  input \result_out_reg[0] ;
  input clk_IBUF_BUFG;
  input \result_out_reg[0]_0 ;
  input [4:0]Q;
  input [0:0]\result_reg[0]_0 ;
  input [1:0]\result_out_reg[1] ;
  input [1:0]\result_out_reg[1]_0 ;

  wire B0_n_0;
  wire B1_n_0;
  wire B2_n_0;
  wire B3_n_0;
  wire [4:0]D;
  wire H0_n_0;
  wire H0_n_1;
  wire H1_n_0;
  wire H1_n_1;
  wire [4:0]Q;
  wire clk_IBUF_BUFG;
  wire \pe_result[4]_i_2__0_n_0 ;
  wire \result_out_reg[0] ;
  wire \result_out_reg[0]_0 ;
  wire [1:0]\result_out_reg[1] ;
  wire [1:0]\result_out_reg[1]_0 ;
  wire [0:0]\result_reg[0]_0 ;
  wire \result_reg_n_0_[0] ;
  wire \result_reg_n_0_[1] ;
  wire \result_reg_n_0_[2] ;
  wire \result_reg_n_0_[3] ;

  PIPO_15 B0
       (.D(B0_n_0),
        .Q(H0_n_1),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (\result_out_reg[0]_0 ));
  PIPO_16 B1
       (.clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (B1_n_0),
        .\d_out_reg[0]_1 (\result_out_reg[0] ),
        .\d_out_reg[0]_2 (\result_out_reg[1]_0 [1]),
        .\d_out_reg[0]_3 (\result_out_reg[1] [1]));
  PIPO_17 B2
       (.clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (B2_n_0),
        .\d_out_reg[0]_1 (\result_out_reg[0] ),
        .\d_out_reg[0]_2 (\result_out_reg[1]_0 [0]),
        .\d_out_reg[0]_3 (\result_out_reg[1] [0]));
  PIPO_18 B3
       (.D(B3_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (\result_out_reg[0]_0 ),
        .\d_out_reg[0]_1 (B2_n_0));
  adder_19 H0
       (.Q({H0_n_0,H0_n_1}),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\result_out_reg[0]_0 (\result_out_reg[0] ),
        .\result_out_reg[1]_0 (\result_out_reg[1] ),
        .\result_out_reg[1]_1 (\result_out_reg[1]_0 ));
  adder_20 H1
       (.Q(H0_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\result_out_reg[0]_0 (B1_n_0),
        .\result_out_reg[0]_1 (\result_out_reg[0]_0 ),
        .\result_out_reg[1]_0 ({H1_n_0,H1_n_1}));
  (* \PinAttr:I1:HOLD_DETOUR  = "194" *) 
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \pe_result[0]_i_1__0 
       (.I0(\result_reg_n_0_[0] ),
        .I1(Q[0]),
        .O(D[0]));
  (* \PinAttr:I0:HOLD_DETOUR  = "194" *) 
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT4 #(
    .INIT(16'h8778)) 
    \pe_result[1]_i_1__0 
       (.I0(Q[0]),
        .I1(\result_reg_n_0_[0] ),
        .I2(Q[1]),
        .I3(\result_reg_n_0_[1] ),
        .O(D[1]));
  LUT6 #(
    .INIT(64'hE88817771777E888)) 
    \pe_result[2]_i_1__0 
       (.I0(\result_reg_n_0_[1] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(\result_reg_n_0_[0] ),
        .I4(Q[2]),
        .I5(\result_reg_n_0_[2] ),
        .O(D[2]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \pe_result[3]_i_1__0 
       (.I0(\pe_result[4]_i_2__0_n_0 ),
        .I1(Q[3]),
        .I2(\result_reg_n_0_[3] ),
        .O(D[3]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'h65A6)) 
    \pe_result[4]_i_1__0 
       (.I0(Q[4]),
        .I1(\result_reg_n_0_[3] ),
        .I2(\pe_result[4]_i_2__0_n_0 ),
        .I3(Q[3]),
        .O(D[4]));
  LUT6 #(
    .INIT(64'h00151555557F7FFF)) 
    \pe_result[4]_i_2__0 
       (.I0(\result_reg_n_0_[2] ),
        .I1(\result_reg_n_0_[0] ),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(\result_reg_n_0_[1] ),
        .I5(Q[2]),
        .O(\pe_result[4]_i_2__0_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[0]_0 ),
        .D(B3_n_0),
        .Q(\result_reg_n_0_[0] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[0]_0 ),
        .D(B0_n_0),
        .Q(\result_reg_n_0_[1] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[0]_0 ),
        .D(H1_n_1),
        .Q(\result_reg_n_0_[2] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[0]_0 ),
        .D(H1_n_0),
        .Q(\result_reg_n_0_[3] ),
        .R(1'b0));
endmodule

(* ORIG_REF_NAME = "vedic_2x2" *) 
module vedic_2x2_21
   (E,
    done_reg_0,
    done_reg_1,
    D,
    reset_n_IBUF,
    do_mul_reg,
    clk_IBUF_BUFG,
    \pe_result_reg[0] ,
    Q,
    \result_reg[3]_0 ,
    \result_out_reg[1] ,
    \result_out_reg[1]_0 );
  output [0:0]E;
  output [0:0]done_reg_0;
  output [0:0]done_reg_1;
  output [4:0]D;
  input reset_n_IBUF;
  input do_mul_reg;
  input clk_IBUF_BUFG;
  input [0:0]\pe_result_reg[0] ;
  input [4:0]Q;
  input [0:0]\result_reg[3]_0 ;
  input [1:0]\result_out_reg[1] ;
  input [1:0]\result_out_reg[1]_0 ;

  wire B1_n_0;
  wire B2_n_1;
  wire [4:0]D;
  wire [0:0]E;
  wire [4:0]Q;
  wire clk_IBUF_BUFG;
  wire do_mul_reg;
  wire done;
  wire [0:0]done_reg_0;
  wire [0:0]done_reg_1;
  wire done_s2_3;
  wire [3:0]in;
  wire \pe11/inst_vedic_2x2/done_s1_3 ;
  wire \pe_result[4]_i_2_n_0 ;
  wire [0:0]\pe_result_reg[0] ;
  wire reset_n_IBUF;
  wire [1:0]result_out;
  wire [1:0]\result_out_reg[1] ;
  wire [1:0]\result_out_reg[1]_0 ;
  wire [0:0]\result_reg[3]_0 ;
  wire [3:0]result_w;

  PIPO_22 B0
       (.D(result_w[1]),
        .E(done_reg_0),
        .Q(result_out[0]),
        .clk_IBUF_BUFG(clk_IBUF_BUFG));
  PIPO_23 B1
       (.E(E),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (B1_n_0),
        .\d_out_reg[0]_1 (\result_out_reg[1]_0 [1]),
        .\d_out_reg[0]_2 (\result_out_reg[1] [1]));
  PIPO_24 B2
       (.E(E),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (B2_n_1),
        .\d_out_reg[0]_1 (\result_out_reg[1]_0 [0]),
        .\d_out_reg[0]_2 (\result_out_reg[1] [0]),
        .do_mul_reg(do_mul_reg),
        .done_reg_0(done_reg_0),
        .done_s1_3(\pe11/inst_vedic_2x2/done_s1_3 ),
        .reset_n_IBUF(reset_n_IBUF));
  PIPO_25 B3
       (.D(result_w[0]),
        .E(done_reg_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (B2_n_1),
        .done_s1_3(\pe11/inst_vedic_2x2/done_s1_3 ),
        .done_s2_3(done_s2_3),
        .reset_n_IBUF(reset_n_IBUF));
  adder_26 H0
       (.E(E),
        .Q(result_out),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .do_mul_reg(do_mul_reg),
        .reset_n_IBUF(reset_n_IBUF),
        .\result_out_reg[1]_0 (\result_out_reg[1] ),
        .\result_out_reg[1]_1 (\result_out_reg[1]_0 ));
  adder_27 H1
       (.E(done_reg_0),
        .Q(result_out[1]),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\result_out_reg[0]_0 (B1_n_0),
        .\result_out_reg[1]_0 (result_w[3:2]));
  FDRE #(
    .INIT(1'b0)) 
    done_reg
       (.C(clk_IBUF_BUFG),
        .CE(1'b1),
        .D(done_s2_3),
        .Q(done),
        .R(reset_n_IBUF));
  (* \PinAttr:I1:HOLD_DETOUR  = "194" *) 
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \pe_result[0]_i_1 
       (.I0(in[0]),
        .I1(Q[0]),
        .O(D[0]));
  (* \PinAttr:I0:HOLD_DETOUR  = "194" *) 
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h8778)) 
    \pe_result[1]_i_1 
       (.I0(Q[0]),
        .I1(in[0]),
        .I2(Q[1]),
        .I3(in[1]),
        .O(D[1]));
  LUT6 #(
    .INIT(64'hE88817771777E888)) 
    \pe_result[2]_i_1 
       (.I0(in[1]),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(in[0]),
        .I4(Q[2]),
        .I5(in[2]),
        .O(D[2]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \pe_result[3]_i_1 
       (.I0(\pe_result[4]_i_2_n_0 ),
        .I1(Q[3]),
        .I2(in[3]),
        .O(D[3]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'h65A6)) 
    \pe_result[4]_i_1 
       (.I0(Q[4]),
        .I1(in[3]),
        .I2(\pe_result[4]_i_2_n_0 ),
        .I3(Q[3]),
        .O(D[4]));
  LUT6 #(
    .INIT(64'h00151555557F7FFF)) 
    \pe_result[4]_i_2 
       (.I0(in[2]),
        .I1(in[0]),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(in[1]),
        .I5(Q[2]),
        .O(\pe_result[4]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[3]_0 ),
        .D(result_w[0]),
        .Q(in[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[3]_0 ),
        .D(result_w[1]),
        .Q(in[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[3]_0 ),
        .D(result_w[2]),
        .Q(in[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[3]_0 ),
        .D(result_w[3]),
        .Q(in[3]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h2)) 
    \row_out[1]_i_1 
       (.I0(done),
        .I1(\pe_result_reg[0] ),
        .O(done_reg_1));
endmodule

(* ORIG_REF_NAME = "vedic_2x2" *) 
module vedic_2x2_7
   (D,
    \result_out_reg[0] ,
    clk_IBUF_BUFG,
    \result_out_reg[0]_0 ,
    Q,
    \result_reg[3]_0 ,
    \result_out_reg[1] ,
    \result_out_reg[1]_0 );
  output [4:0]D;
  input \result_out_reg[0] ;
  input clk_IBUF_BUFG;
  input \result_out_reg[0]_0 ;
  input [4:0]Q;
  input [0:0]\result_reg[3]_0 ;
  input [1:0]\result_out_reg[1] ;
  input [1:0]\result_out_reg[1]_0 ;

  wire B0_n_0;
  wire B1_n_0;
  wire B2_n_0;
  wire B3_n_0;
  wire [4:0]D;
  wire H0_n_0;
  wire H0_n_1;
  wire H1_n_0;
  wire H1_n_1;
  wire [4:0]Q;
  wire clk_IBUF_BUFG;
  wire \pe_result[4]_i_2__1_n_0 ;
  wire \result_out_reg[0] ;
  wire \result_out_reg[0]_0 ;
  wire [1:0]\result_out_reg[1] ;
  wire [1:0]\result_out_reg[1]_0 ;
  wire [0:0]\result_reg[3]_0 ;
  wire \result_reg_n_0_[0] ;
  wire \result_reg_n_0_[1] ;
  wire \result_reg_n_0_[2] ;
  wire \result_reg_n_0_[3] ;

  PIPO_8 B0
       (.D(B0_n_0),
        .Q(H0_n_1),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (\result_out_reg[0]_0 ));
  PIPO_9 B1
       (.clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (B1_n_0),
        .\d_out_reg[0]_1 (\result_out_reg[0] ),
        .\d_out_reg[0]_2 (\result_out_reg[1]_0 [1]),
        .\d_out_reg[0]_3 (\result_out_reg[1] [1]));
  PIPO_10 B2
       (.clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (B2_n_0),
        .\d_out_reg[0]_1 (\result_out_reg[0] ),
        .\d_out_reg[0]_2 (\result_out_reg[1]_0 [0]),
        .\d_out_reg[0]_3 (\result_out_reg[1] [0]));
  PIPO_11 B3
       (.D(B3_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\d_out_reg[0]_0 (\result_out_reg[0]_0 ),
        .\d_out_reg[0]_1 (B2_n_0));
  adder_12 H0
       (.Q({H0_n_0,H0_n_1}),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\result_out_reg[0]_0 (\result_out_reg[0] ),
        .\result_out_reg[1]_0 (\result_out_reg[1] ),
        .\result_out_reg[1]_1 (\result_out_reg[1]_0 ));
  adder_13 H1
       (.Q(H0_n_0),
        .clk_IBUF_BUFG(clk_IBUF_BUFG),
        .\result_out_reg[0]_0 (B1_n_0),
        .\result_out_reg[0]_1 (\result_out_reg[0]_0 ),
        .\result_out_reg[1]_0 ({H1_n_0,H1_n_1}));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \pe_result[0]_i_1__1 
       (.I0(\result_reg_n_0_[0] ),
        .I1(Q[0]),
        .O(D[0]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT4 #(
    .INIT(16'h8778)) 
    \pe_result[1]_i_1__1 
       (.I0(Q[0]),
        .I1(\result_reg_n_0_[0] ),
        .I2(Q[1]),
        .I3(\result_reg_n_0_[1] ),
        .O(D[1]));
  LUT6 #(
    .INIT(64'hE88817771777E888)) 
    \pe_result[2]_i_1__1 
       (.I0(\result_reg_n_0_[1] ),
        .I1(Q[1]),
        .I2(Q[0]),
        .I3(\result_reg_n_0_[0] ),
        .I4(Q[2]),
        .I5(\result_reg_n_0_[2] ),
        .O(D[2]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'h69)) 
    \pe_result[3]_i_1__1 
       (.I0(\pe_result[4]_i_2__1_n_0 ),
        .I1(Q[3]),
        .I2(\result_reg_n_0_[3] ),
        .O(D[3]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT4 #(
    .INIT(16'h65A6)) 
    \pe_result[4]_i_1__1 
       (.I0(Q[4]),
        .I1(\result_reg_n_0_[3] ),
        .I2(\pe_result[4]_i_2__1_n_0 ),
        .I3(Q[3]),
        .O(D[4]));
  LUT6 #(
    .INIT(64'h00151555557F7FFF)) 
    \pe_result[4]_i_2__1 
       (.I0(\result_reg_n_0_[2] ),
        .I1(\result_reg_n_0_[0] ),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(\result_reg_n_0_[1] ),
        .I5(Q[2]),
        .O(\pe_result[4]_i_2__1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[0] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[3]_0 ),
        .D(B3_n_0),
        .Q(\result_reg_n_0_[0] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[1] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[3]_0 ),
        .D(B0_n_0),
        .Q(\result_reg_n_0_[1] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[2] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[3]_0 ),
        .D(H1_n_1),
        .Q(\result_reg_n_0_[2] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \result_reg[3] 
       (.C(clk_IBUF_BUFG),
        .CE(\result_reg[3]_0 ),
        .D(H1_n_0),
        .Q(\result_reg_n_0_[3] ),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
