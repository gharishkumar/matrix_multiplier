`timescale 1ns / 1ps

module counter(
    input wire       button_n, //start and stop button. Count only start when this button is pressed. Press again becomes stop. Resume back to count if pressed after stop
    input wire       reset_n, //reset button 
    input wire       clk_point1hz,  //input counter clock 
    output reg [3:0] reg_d0, //count for right most digit
    output reg [3:0] reg_d1 //count for 2nd right most digit
    );

    reg button_n_ff; //button flip-flop register variable
    reg start_stop; //start, stop or resume signal 
    reg reset_n_ff; //reset button flip-flop register variable
    reg reset; //reset signal

    always @ (posedge clk_point1hz) // look for the edge of the button. Use active low logic
        begin
            button_n_ff <= button_n; //assign button flip flop from button 
            if (button_n_ff && !button_n) // if button_n_ff = 1 && button_n = 0 
                    start_stop <= ~start_stop; 
            reset_n_ff <= reset_n; //assign reset button flip flop from reset button
            if (reset_n_ff && !reset_n) // if reset_n_ff = 1 && reset_n = 0
                reset <=1; //assert reset signal
            else
                reset <=0; //when the reset button is not negative edge, reset signal is low
        end

    always @(posedge clk_point1hz) //counter logic
    begin
         if (start_stop == 1 && reset ==1) //if both stop & reset asserted 
            begin 
                reg_d0 <= 1; //counter0 is 1
                reg_d1 <= 1; //counter1 is 1
            // if only stop signal is asserted, store the previous count
            // when stop button is pressed again, resume the old count
            end else if (start_stop == 1) 
            begin
                reg_d0 <= reg_d0; //store the old count
                reg_d1 <= reg_d1; //store the old count
            end else if (start_stop != 1) //if no stop
            begin
              if(reg_d0 == 2) // if count is xxx2 
              begin
                 reg_d0 <= 1; //assign count0 to 1
                 if (reg_d1 == 2) //if count is xx22
                     begin
                        reg_d1 <= 1; //assign count1 to 1
                     end else //else case for count xx22
                         reg_d1 <= reg_d1 + 1; 
              end else // else case for count xxx2
                reg_d0 <= reg_d0 + 1;
             end
    end
    
endmodule
