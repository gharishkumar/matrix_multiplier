`timescale 1ns / 1ps

module fsm_button(
    input  wire clk,
    input  wire reset,
    input  wire btn,
    output wire d_out
    );

    parameter RESET_C = 1'b0;
    parameter ASSERT_C = 1'b1;

    reg  button;
    reg state;

    always @(posedge clk or posedge reset) begin
        if(reset) begin
            state <= RESET_C;
            button <= 0;
        end  else begin
            case(state) 
                RESET_C : 
                        begin
                            if(btn) begin
                                button<= 1'b1;
                                state <= ASSERT_C;
                            end else begin
                                button<= 1'b0;
                                state <= RESET_C;
                            end
                        end

                ASSERT_C : 
                        begin
                            if(btn) begin
                                button<= 1'b0;
                                state <= ASSERT_C;
                            end else begin
                                button<= 1'b0;
                                state <= RESET_C;
                            end
                        end

                default : 
                        begin
                            button<= 1'b0;
                            state <= RESET_C;
                        end
            endcase
        end
    end

    assign d_out = button;

endmodule

