`timescale 1ns / 1ps

module ssd(
		input wire  [3:0] hex, //hexadecimal number, 2^4=16 from 0 to F. Other use until 9
		output reg  [6:0] segment // 7 segment output
    );

	//active low logic to turn on the segment
	//use case statement to represent each hexadecimal number
	always @ (*)
		case (hex) 
			1: segment = 7'b1001111;
			2: segment = 7'b0010010;
	      default: segment = 7'b1111111; //default is 0 
		endcase	
    
endmodule
