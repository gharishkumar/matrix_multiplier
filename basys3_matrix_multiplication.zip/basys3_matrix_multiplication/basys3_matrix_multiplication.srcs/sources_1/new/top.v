`timescale 1ns / 1ps

module top(
    input  wire        clk,//clock
    input  wire        button_n, //stop button
    input  wire        reset_n, //reset button
    input  wire [15:0] sw,
    output wire  [6:0] segment, // seven segment display
    output wire        enable_D1,//right most digit
    output wire        enable_D2,//second right most digit
    output wire        enable_D3,//second left most digit
    output wire        enable_D4,//left most digit
    input  wire        load, //load in
    output wire        valid_output,
    output reg   [4:0] led
    );

    wire clk_point1hz; //counter clock
    wire refreshClk; ////refresh the display
    reg  [3:0] hex; //hexadecimal number
    wire [3:0] reg_d0; //count for right digit
    wire [3:0] reg_d1; //count for left digit
    wire load_in_wrapper;

    //load_in fsm 
    fsm_button inst(
        .clk(clk),
        .reset(reset_n),
        .btn(load),
        .d_out(load_in_wrapper)
    );

    // wrapper inst
    wire [19:0] matrix_result;

    mat_wrapper inst_wrapper(
        .clk(clk),
        .rst(reset_n),
        .load_in(load_in_wrapper),
        .a11(sw[1:0]),
        .a12(sw[3:2]),
        .a21(sw[5:4]),
        .a22(sw[7:6]),
        .b11(sw[9:8]),
        .b12(sw[11:10]),
        .b21(sw[13:12]),
        .b22(sw[15:14]),
        .result_out(matrix_result),
        .valid(valid_output)
    );

    //instantiate the clock 
    clkgen Uclkgen(
        .clk(clk),
        .refreshClk(refreshClk),
        .clk_point1hz(clk_point1hz)
    );

    //instantiate enable_sr
    enable_sr Uenable(
        .refreshClk(refreshClk),
        .enable_D1(enable_D1),
        .enable_D2(enable_D2),
        .enable_D3(enable_D3),
        .enable_D4(enable_D4)
    );

    //instantiate counter
    counter Ucounter(
        .button_n(button_n),
        .reset_n(reset_n),
        .clk_point1hz(clk_point1hz),
        .reg_d0(reg_d0),
        .reg_d1(reg_d1)
    );

    //instantiate ssd 
    ssd Ussd(
        .hex(hex),
        .segment(segment)
    );

    //use case satement to assign hexadecimal to each digit
    //condition is which digit is on

    always @ (*) begin
        case ({reg_d1,reg_d0})
            8'b0001_0001: led = matrix_result[4:0];//result11
            8'b0001_0010: led = matrix_result[9:5];//result12
            8'b0010_0001: led = matrix_result[14:10];//result21
            8'b0010_0010: led = matrix_result[19:15];//result22
            default: led = 0; 
        endcase 
    end

    always @ (*) begin
        case ({enable_D1,enable_D2})
            2'b01: hex = reg_d0;
            2'b10: hex = reg_d1;
            default: hex = 0; 
        endcase
    end

endmodule
