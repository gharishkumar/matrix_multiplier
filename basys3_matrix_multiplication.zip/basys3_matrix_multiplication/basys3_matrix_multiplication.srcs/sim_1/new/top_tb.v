`timescale 1ns / 1ps

module top_tb;

    // Inputs
    reg clk;
    reg button_n;
    reg reset_n;
    reg [15:0] sw;
    reg load;

    // Outputs
    wire [6:0] segment;
    wire enable_D1;
    wire enable_D2;
    wire enable_D3;
    wire enable_D4;
    wire valid_output;
    wire [4:0] led;

    // Instantiate the Unit Under Test (UUT)
    top uut (
        .clk(clk),
        .button_n(button_n),
        .reset_n(reset_n),
        .sw(sw),
        .segment(segment),
        .enable_D1(enable_D1),
        .enable_D2(enable_D2),
        .enable_D3(enable_D3),
        .enable_D4(enable_D4),
        .load(load),
        .valid_output(valid_output),
        .led(led)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 100 MHz clock (10 ns period)
    end

    // Testbench logic
    initial begin
        // Initialize inputs
        button_n = 1;
        reset_n = 1;
        sw = 16'h0000;
        load = 0;

        // Apply reset
        #20;
        reset_n = 0;

        // Test case 1: Load matrix values and observe outputs
        #200;
        sw = 16'h61b5; // Example matrix values
        load = 1;
        #20;
        load = 0;

        // Wait for valid output
        #200000;

        // End simulation
        $stop;
    end

endmodule
